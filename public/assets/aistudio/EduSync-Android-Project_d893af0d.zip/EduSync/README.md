# EduSync: Production-Ready Offline-First Android App

EduSync is a full-featured, production-ready educational management Android application built with **Kotlin**, **Jetpack Compose (Material 3)**, **Room Database**, and a **Supabase (PostgreSQL)** backend adhering to clean **MVVM Architecture**.

It provides enterprise-grade offline synchronization, role-based access control (Admin & Student), real-time cloud data push/pull, automatic cross-device backup and restore with SHA-256 integrity verification, robust database migrations, and chunked batch handling for thousands of records without SQLite bind limits or UI frame drops.

---

## 🏛️ System Architecture

```
                                  ┌───────────────────────────┐
                                  │   Supabase Cloud Backend  │
                                  │ (PostgreSQL, GoTrue, RLS, │
                                  │    Realtime WebSockets)   │
                                  └─────────────▲─────────────┘
                                                │
                                    HTTPS / WSS (Ktor Engine)
                                                │
                                  ┌─────────────▼─────────────┐
                                  │   Supabase Client SDK     │
                                  │ (Auth, Postgrest, Realtime│
                                  └─────────────▲─────────────┘
                                                │
                          ┌─────────────────────┴─────────────────────┐
                          │                                           │
              ┌───────────▼───────────┐                   ┌───────────▼───────────┐
              │     SyncWorker /      │                   │   Remote Services     │
              │  RealtimeManager      │                   │ (Auth, Course, Backup)│
              └───────────▲───────────┘                   └───────────▲───────────┘
                          │                                           │
  ┌───────────────────────┴───────────────────────────────────────────┴───────────────────────┐
  │                                     Repository Layer                                      │
  │     (AuthRepository, CourseRepository, AssignmentRepository, SyncRepo, BackupRestoreRepo) │
  └───────────────────────────────────────────▲───────────────────────────────────────────────┘
                                              │
                      ┌───────────────────────┴───────────────────────┐
                      │                                               │
          ┌───────────▼───────────┐                       ┌───────────▼───────────┐
          │     Domain Models     │                       │    Room Database      │
          │ (Role, Course, Subm.) │                       │ (AppDatabase v2, M1_2)│
          └───────────▲───────────┘                       └───────────▲───────────┘
                      │                                               │
  ┌───────────────────┴───────────────────────────────────────────────┴───────────────────┐
  │                                    UI Layer (MVVM)                                    │
  │    (AuthViewModel, AdminViewModel, StudentViewModel, SettingsViewModel, Compose M3)   │
  └───────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Key Production Features

### 1. Role-Based Access Control (Admin & Student)
- **Admin**:
  - Full management of course offerings, curriculum descriptions, and categories.
  - Creation and scheduling of assignments with due dates and point allocations.
  - Grade student submissions with numerical scores and qualitative feedback.
  - Stress-test and benchmark engine: Generate and ingest 1,000+ course records in bounded chunks to verify cache performance.
- **Student**:
  - Browse course catalog and access enrolled coursework.
  - Submit assignment responses (text/code/repository links) with instant offline caching.
  - Real-time grade tracking and resubmission capabilities.

### 2. Offline-First Sync & Conflict Resolution
- **Outbound Queue (`sync_queue`)**: All offline creations, modifications, and deletions are saved to Room with `PENDING_INSERT`, `PENDING_UPDATE`, or `PENDING_DELETE` statuses and queued in SQLite.
- **Idempotency & Retries**: Every mutation carries an immutable UUID. If network operations fail, `SyncWorker` retries using exponential backoff up to 5 attempts before flagging as failed.
- **Last-Write-Wins (LWW)**: Timestamps (`updated_at`) ensure conflicts between concurrent offline modifications and remote edits resolve deterministically.
- **Realtime Cloud Replication**: Supabase WebSocket channels automatically push database modifications from Postgres directly to client devices.

### 3. High-Volume Performance (Thousands of Records)
- High-volume record operations are partitioned into chunks of 250 items via `@Transaction` chunked upserts.
- SQLite bind parameter limits (999 variables) are completely bypassed.
- Indices on `updated_at`, `is_archived`, `category`, and foreign keys prevent full table scans.

### 4. Database Schema Migration (v1 -> v2)
- Explicit `MIGRATION_1_2` script executes column additions (`device_id`, `category`, `enrolled_count`, `is_archived`, `sync_status`) and creates the `sync_queue` table with indexes without data loss.

### 5. Automatic Cross-Device Backup & Restore
- Full state snapshots across courses, assignments, and submissions are serialized to JSON.
- Cryptographic **SHA-256 checksums** verify snapshot integrity before cloud upload and before device restore.
- Enables seamless switching between smartphones, tablets, or new devices.

### 6. Modern Material 3 UI
- Clean adaptive light and dark themes with WCAG AA compliance.
- Animated `OfflineStatusBar` banner informs users when working completely disconnected.
- Reactive `SyncIndicator` badge showing pending queue count and animated rotating sync status.

---

## 🛠️ Project Structure

```
EduSync/
├── .github/workflows/android.yml      # CI workflow for lint, unit tests & build
├── gradle/
│   ├── libs.versions.toml             # Gradle Version Catalog
│   └── wrapper/                       # Gradle wrapper configuration
├── supabase/
│   └── schema.sql                     # Complete PostgreSQL DDL with RLS and Realtime
├── app/
│   ├── build.gradle.kts               # Module build configuration (KSP, Room, Supabase)
│   ├── proguard-rules.pro             # Obfuscation & R8 retention rules
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── res/                   # Drawables, strings, colors, themes
│       │   └── java/com/edusync/app/
│       │       ├── EduSyncApplication.kt
│       │       ├── MainActivity.kt
│       │       ├── core/              # Constants, NetworkMonitor, TokenManager
│       │       ├── data/
│       │       │   ├── local/         # Room Database, Converters, DAOs, Entities
│       │       │   ├── remote/        # Supabase API services, DTOs, Realtime
│       │       │   └── repository/    # Offline-first repositories
│       │       ├── domain/            # Models (Role, Course, User) and Mappers
│       │       ├── sync/              # WorkManager SyncWorker & SyncManager
│       │       ├── di/                # AppContainer dependency injection
│       │       └── ui/                # Compose screens, ViewModels, Theme
│       └── test/java/com/edusync/app/ # Room migration, mapping & sync unit tests
```

---

## ⚡ Build Commands & Execution

Ensure JDK 17 is active in your terminal environment.

### 1. Clean & Validate Project
```bash
./gradlew clean
```

### 2. Run All Unit Tests
```bash
./gradlew testDebugUnitTest
```

### 3. Assemble Debug APK
```bash
./gradlew assembleDebug
```
*Output path:* `app/build/outputs/apk/debug/app-debug.apk`

### 4. Assemble Release APK (with Proguard / R8 Optimization)
```bash
./gradlew assembleRelease
```
*Output path:* `app/build/outputs/apk/release/app-release.apk`

---

## ☁️ Supabase Cloud Setup

1. Open your [Supabase Dashboard](https://supabase.com).
2. Open the **SQL Editor** tab.
3. Paste the contents of `supabase/schema.sql` and click **Run**.
4. Navigate to **Project Settings -> API** and copy:
   - **Project URL**
   - **anon / public key**
5. Open `app/src/main/java/com/edusync/app/core/Constants.kt` and replace `SUPABASE_URL` and `SUPABASE_ANON_KEY` with your credentials.
