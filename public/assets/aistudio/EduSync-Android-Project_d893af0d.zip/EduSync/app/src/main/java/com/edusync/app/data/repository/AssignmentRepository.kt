package com.edusync.app.data.repository

import com.edusync.app.core.DispatcherProvider
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.data.local.dao.AssignmentDao
import com.edusync.app.data.local.dao.SubmissionDao
import com.edusync.app.data.local.dao.SyncQueueDao
import com.edusync.app.data.local.entity.SyncQueueEntity
import com.edusync.app.data.remote.api.SupabaseCourseService
import com.edusync.app.domain.mapper.AssignmentMapper
import com.edusync.app.domain.mapper.SubmissionMapper
import com.edusync.app.domain.model.Assignment
import com.edusync.app.domain.model.Submission
import com.edusync.app.domain.model.SubmissionStatus
import com.edusync.app.domain.model.SyncEntityType
import com.edusync.app.domain.model.SyncOperationType
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

interface AssignmentRepository {
    fun observeAssignments(courseId: String): Flow<List<Assignment>>
    fun observeAllAssignments(): Flow<List<Assignment>>
    suspend fun getAssignmentById(id: String): Assignment?
    suspend fun createAssignment(assignment: Assignment): Resource<Assignment>
    suspend fun deleteAssignment(id: String): Resource<Unit>

    fun observeSubmission(assignmentId: String, studentId: String): Flow<Submission?>
    fun observeStudentSubmissions(studentId: String): Flow<List<Submission>>
    fun observeSubmissionsForAssignment(assignmentId: String): Flow<List<Submission>>
    suspend fun submitWork(assignmentId: String, studentId: String, content: String): Resource<Submission>
    suspend fun gradeSubmission(submissionId: String, score: Int, feedback: String?): Resource<Unit>
    suspend fun refreshAssignmentsAndSubmissions(studentId: String? = null): Resource<Unit>
}

class AssignmentRepositoryImpl(
    private val assignmentDao: AssignmentDao,
    private val submissionDao: SubmissionDao,
    private val syncQueueDao: SyncQueueDao,
    private val courseService: SupabaseCourseService,
    private val networkMonitor: NetworkMonitor,
    private val dispatchers: DispatcherProvider
) : AssignmentRepository {

    override fun observeAssignments(courseId: String): Flow<List<Assignment>> {
        return assignmentDao.observeAssignmentsByCourse(courseId)
            .map { list -> list.map { AssignmentMapper.toDomain(it) } }
            .flowOn(dispatchers.io)
    }

    override fun observeAllAssignments(): Flow<List<Assignment>> {
        return assignmentDao.observeAllAssignments()
            .map { list -> list.map { AssignmentMapper.toDomain(it) } }
            .flowOn(dispatchers.io)
    }

    override suspend fun getAssignmentById(id: String): Assignment? = withContext(dispatchers.io) {
        assignmentDao.getAssignmentById(id)?.let { AssignmentMapper.toDomain(it) }
    }

    override suspend fun createAssignment(assignment: Assignment): Resource<Assignment> = withContext(dispatchers.io) {
        val now = System.currentTimeMillis()
        val prepared = assignment.copy(
            id = if (assignment.id.isBlank()) UUID.randomUUID().toString() else assignment.id,
            createdAt = if (assignment.createdAt == 0L) now else assignment.createdAt,
            updatedAt = now,
            syncStatus = if (networkMonitor.isCurrentlyConnected()) SyncStatus.SYNCED else SyncStatus.PENDING_INSERT
        )

        val entity = AssignmentMapper.toEntity(prepared)
        assignmentDao.insertOrUpdate(entity)

        if (networkMonitor.isCurrentlyConnected()) {
            val dto = AssignmentMapper.toDto(prepared)
            when (courseService.upsertAssignment(dto)) {
                is Resource.Success -> {
                    assignmentDao.updateSyncStatus(prepared.id, SyncStatus.SYNCED)
                    Resource.Success(prepared.copy(syncStatus = SyncStatus.SYNCED))
                }
                else -> {
                    enqueueAssignment(prepared, SyncOperationType.CREATE)
                    Resource.Success(prepared.copy(syncStatus = SyncStatus.PENDING_INSERT))
                }
            }
        } else {
            enqueueAssignment(prepared, SyncOperationType.CREATE)
            Resource.Success(prepared.copy(syncStatus = SyncStatus.PENDING_INSERT))
        }
    }

    override suspend fun deleteAssignment(id: String): Resource<Unit> = withContext(dispatchers.io) {
        assignmentDao.deleteById(id)
        if (networkMonitor.isCurrentlyConnected()) {
            courseService.deleteAssignment(id)
        }
        Resource.Success(Unit)
    }

    override fun observeSubmission(assignmentId: String, studentId: String): Flow<Submission?> {
        return submissionDao.observeSubmission(assignmentId, studentId)
            .map { it?.let { entity -> SubmissionMapper.toDomain(entity) } }
            .flowOn(dispatchers.io)
    }

    override fun observeStudentSubmissions(studentId: String): Flow<List<Submission>> {
        return submissionDao.observeSubmissionsByStudent(studentId)
            .map { list -> list.map { SubmissionMapper.toDomain(it) } }
            .flowOn(dispatchers.io)
    }

    override fun observeSubmissionsForAssignment(assignmentId: String): Flow<List<Submission>> {
        return submissionDao.observeSubmissionsByAssignment(assignmentId)
            .map { list -> list.map { SubmissionMapper.toDomain(it) } }
            .flowOn(dispatchers.io)
    }

    override suspend fun submitWork(
        assignmentId: String,
        studentId: String,
        content: String
    ): Resource<Submission> = withContext(dispatchers.io) {
        val now = System.currentTimeMillis()
        val existing = submissionDao.getSubmission(assignmentId, studentId)
        val id = existing?.id ?: UUID.randomUUID().toString()

        val submission = Submission(
            id = id,
            assignmentId = assignmentId,
            studentId = studentId,
            content = content,
            score = existing?.score,
            feedback = existing?.feedback,
            status = SubmissionStatus.SUBMITTED,
            submittedAt = existing?.submittedAt ?: now,
            updatedAt = now,
            syncStatus = if (networkMonitor.isCurrentlyConnected()) SyncStatus.SYNCED else SyncStatus.PENDING_INSERT
        )

        val entity = SubmissionMapper.toEntity(submission)
        submissionDao.insertOrUpdate(entity)

        if (networkMonitor.isCurrentlyConnected()) {
            val dto = SubmissionMapper.toDto(submission)
            when (courseService.upsertSubmission(dto)) {
                is Resource.Success -> {
                    submissionDao.updateSyncStatus(submission.id, SyncStatus.SYNCED)
                    Resource.Success(submission.copy(syncStatus = SyncStatus.SYNCED))
                }
                else -> {
                    enqueueSubmission(submission, SyncOperationType.UPDATE)
                    Resource.Success(submission.copy(syncStatus = SyncStatus.PENDING_UPDATE))
                }
            }
        } else {
            enqueueSubmission(submission, SyncOperationType.UPDATE)
            Resource.Success(submission.copy(syncStatus = SyncStatus.PENDING_UPDATE))
        }
    }

    override suspend fun gradeSubmission(
        submissionId: String,
        score: Int,
        feedback: String?
    ): Resource<Unit> = withContext(dispatchers.io) {
        val now = System.currentTimeMillis()
        val existing = submissionDao.getSubmissionById(submissionId)
            ?: return@withContext Resource.Error("Submission not found")

        val graded = existing.copy(
            score = score,
            feedback = feedback,
            status = SubmissionStatus.GRADED,
            updatedAt = now,
            syncStatus = if (networkMonitor.isCurrentlyConnected()) SyncStatus.SYNCED else SyncStatus.PENDING_UPDATE
        )
        submissionDao.insertOrUpdate(graded)

        val domain = SubmissionMapper.toDomain(graded)
        if (networkMonitor.isCurrentlyConnected()) {
            val dto = SubmissionMapper.toDto(domain)
            courseService.upsertSubmission(dto)
        } else {
            enqueueSubmission(domain, SyncOperationType.UPDATE)
        }
        Resource.Success(Unit)
    }

    override suspend fun refreshAssignmentsAndSubmissions(studentId: String?): Resource<Unit> = withContext(dispatchers.io) {
        if (!networkMonitor.isCurrentlyConnected()) {
            return@withContext Resource.Success(Unit)
        }

        // Fetch assignments
        when (val assignResult = courseService.fetchAssignments()) {
            is Resource.Success -> {
                val entities = assignResult.data.map { AssignmentMapper.toEntity(it) }
                assignmentDao.upsertInChunks(entities)
            }
            is Resource.Error -> return@withContext Resource.Error(assignResult.message)
            else -> Unit
        }

        // Fetch submissions
        when (val subResult = courseService.fetchSubmissions(studentId)) {
            is Resource.Success -> {
                val entities = subResult.data.map { SubmissionMapper.toEntity(it) }
                submissionDao.upsertInChunks(entities)
            }
            is Resource.Error -> return@withContext Resource.Error(subResult.message)
            else -> Unit
        }

        Resource.Success(Unit)
    }

    private suspend fun enqueueAssignment(assignment: Assignment, operation: SyncOperationType) {
        val jsonPayload = Json.encodeToString(assignment)
        val queueItem = SyncQueueEntity(
            id = UUID.randomUUID().toString(),
            entityType = SyncEntityType.ASSIGNMENT,
            entityId = assignment.id,
            operation = operation,
            payloadJson = jsonPayload,
            status = SyncStatus.PENDING_INSERT
        )
        syncQueueDao.enqueue(queueItem)
    }

    private suspend fun enqueueSubmission(submission: Submission, operation: SyncOperationType) {
        val jsonPayload = Json.encodeToString(submission)
        val queueItem = SyncQueueEntity(
            id = UUID.randomUUID().toString(),
            entityType = SyncEntityType.SUBMISSION,
            entityId = submission.id,
            operation = operation,
            payloadJson = jsonPayload,
            status = SyncStatus.PENDING_INSERT
        )
        syncQueueDao.enqueue(queueItem)
    }
}
