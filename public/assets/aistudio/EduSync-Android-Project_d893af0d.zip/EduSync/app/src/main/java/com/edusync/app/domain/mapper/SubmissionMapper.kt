package com.edusync.app.domain.mapper

import com.edusync.app.data.local.entity.SubmissionEntity
import com.edusync.app.data.remote.dto.SubmissionDto
import com.edusync.app.domain.model.Submission
import com.edusync.app.domain.model.SubmissionStatus
import com.edusync.app.domain.model.SyncStatus
import java.time.Instant

object SubmissionMapper {

    fun toDomain(entity: SubmissionEntity): Submission {
        return Submission(
            id = entity.id,
            assignmentId = entity.assignmentId,
            studentId = entity.studentId,
            content = entity.content,
            score = entity.score,
            feedback = entity.feedback,
            status = entity.status,
            submittedAt = entity.submittedAt,
            updatedAt = entity.updatedAt,
            syncStatus = entity.syncStatus
        )
    }

    fun toEntity(domain: Submission, syncStatus: SyncStatus? = null): SubmissionEntity {
        return SubmissionEntity(
            id = domain.id,
            assignmentId = domain.assignmentId,
            studentId = domain.studentId,
            content = domain.content,
            score = domain.score,
            feedback = domain.feedback,
            status = domain.status,
            submittedAt = domain.submittedAt,
            updatedAt = domain.updatedAt,
            syncStatus = syncStatus ?: domain.syncStatus
        )
    }

    fun toEntity(dto: SubmissionDto, syncStatus: SyncStatus = SyncStatus.SYNCED): SubmissionEntity {
        val now = System.currentTimeMillis()
        val submittedEpoch = UserMapper.parseIsoToEpoch(dto.submittedAt, now)
        val updatedEpoch = UserMapper.parseIsoToEpoch(dto.updatedAt, now)

        return SubmissionEntity(
            id = dto.id,
            assignmentId = dto.assignmentId,
            studentId = dto.studentId,
            content = dto.content,
            score = dto.score,
            feedback = dto.feedback,
            status = SubmissionStatus.fromString(dto.status),
            submittedAt = submittedEpoch,
            updatedAt = updatedEpoch,
            syncStatus = syncStatus
        )
    }

    fun toDto(domain: Submission): SubmissionDto {
        return SubmissionDto(
            id = domain.id,
            assignmentId = domain.assignmentId,
            studentId = domain.studentId,
            content = domain.content,
            score = domain.score,
            feedback = domain.feedback,
            status = domain.status.name,
            submittedAt = Instant.ofEpochMilli(domain.submittedAt).toString(),
            updatedAt = Instant.ofEpochMilli(domain.updatedAt).toString()
        )
    }
}
