package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class SubmissionStatus {
    SUBMITTED,
    GRADED,
    LATE,
    RETURNED;

    companion object {
        fun fromString(value: String?): SubmissionStatus {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: SUBMITTED
        }
    }
}

@Serializable
data class Submission(
    val id: String,
    val assignmentId: String,
    val studentId: String,
    val content: String,
    val score: Int?,
    val feedback: String?,
    val status: SubmissionStatus,
    val submittedAt: Long,
    val updatedAt: Long,
    val syncStatus: SyncStatus = SyncStatus.SYNCED
)
