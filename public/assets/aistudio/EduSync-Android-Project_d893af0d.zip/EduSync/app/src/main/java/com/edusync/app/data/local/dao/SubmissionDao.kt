package com.edusync.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.edusync.app.core.Constants
import com.edusync.app.data.local.entity.SubmissionEntity
import com.edusync.app.domain.model.SubmissionStatus
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface SubmissionDao {

    @Query("SELECT * FROM submissions WHERE student_id = :studentId ORDER BY updated_at DESC")
    fun observeSubmissionsByStudent(studentId: String): Flow<List<SubmissionEntity>>

    @Query("SELECT * FROM submissions WHERE assignment_id = :assignmentId ORDER BY submitted_at ASC")
    fun observeSubmissionsByAssignment(assignmentId: String): Flow<List<SubmissionEntity>>

    @Query("SELECT * FROM submissions WHERE assignment_id = :assignmentId AND student_id = :studentId LIMIT 1")
    fun observeSubmission(assignmentId: String, studentId: String): Flow<SubmissionEntity?>

    @Query("SELECT * FROM submissions WHERE assignment_id = :assignmentId AND student_id = :studentId LIMIT 1")
    suspend fun getSubmission(assignmentId: String, studentId: String): SubmissionEntity?

    @Query("SELECT * FROM submissions WHERE id = :id LIMIT 1")
    suspend fun getSubmissionById(id: String): SubmissionEntity?

    @Query("SELECT * FROM submissions")
    suspend fun getAllSubmissions(): List<SubmissionEntity>

    @Query("SELECT COUNT(*) FROM submissions")
    suspend fun getSubmissionCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(submission: SubmissionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(submissions: List<SubmissionEntity>)

    @Update
    suspend fun update(submission: SubmissionEntity)

    @Query("UPDATE submissions SET score = :score, feedback = :feedback, status = :status, updated_at = :updatedAt, sync_status = :syncStatus WHERE id = :id")
    suspend fun gradeSubmission(
        id: String,
        score: Int,
        feedback: String?,
        status: SubmissionStatus,
        updatedAt: Long,
        syncStatus: SyncStatus
    )

    @Query("UPDATE submissions SET sync_status = :status WHERE id = :id")
    suspend fun updateSyncStatus(id: String, status: SyncStatus)

    @Query("DELETE FROM submissions WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM submissions")
    suspend fun clearAll()

    @Transaction
    suspend fun upsertInChunks(submissions: List<SubmissionEntity>, chunkSize: Int = Constants.BATCH_CHUNK_SIZE) {
        submissions.chunked(chunkSize).forEach { chunk ->
            insertAll(chunk)
        }
    }
}
