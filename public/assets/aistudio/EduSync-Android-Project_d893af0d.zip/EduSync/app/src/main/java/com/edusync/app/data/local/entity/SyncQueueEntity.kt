package com.edusync.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.edusync.app.domain.model.SyncEntityType
import com.edusync.app.domain.model.SyncOperationType
import com.edusync.app.domain.model.SyncStatus

@Entity(
    tableName = "sync_queue",
    indices = [
        Index(value = ["status", "created_at"]),
        Index(value = ["entity_type", "entity_id"])
    ]
)
data class SyncQueueEntity(
    @PrimaryKey
    val id: String,
    @ColumnInfo(name = "entity_type")
    val entityType: SyncEntityType,
    @ColumnInfo(name = "entity_id")
    val entityId: String,
    val operation: SyncOperationType,
    @ColumnInfo(name = "payload_json")
    val payloadJson: String,
    @ColumnInfo(name = "retry_count")
    val retryCount: Int = 0,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    val status: SyncStatus = SyncStatus.PENDING_INSERT,
    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null
)
