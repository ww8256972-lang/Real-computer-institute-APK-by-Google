package com.edusync.app

import android.app.Application
import com.edusync.app.di.AppContainer
import com.edusync.app.di.DefaultAppContainer

class EduSyncApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = DefaultAppContainer(this)

        // Initialize background synchronization schedule
        container.syncManager.schedulePeriodicSync()

        // Start listening to Supabase Realtime channel
        container.realtimeManager.startListening()
    }
}
