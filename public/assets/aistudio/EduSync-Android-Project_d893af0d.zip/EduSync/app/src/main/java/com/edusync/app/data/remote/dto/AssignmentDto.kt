package com.edusync.app.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class AssignmentDto(
    @SerialName("id")
    val id: String,
    @SerialName("course_id")
    val courseId: String,
    @SerialName("title")
    val title: String,
    @SerialName("description")
    val description: String = "",
    @SerialName("due_date")
    val dueDate: String,
    @SerialName("max_points")
    val maxPoints: Int = 100,
    @SerialName("created_at")
    val createdAt: String? = null,
    @SerialName("updated_at")
    val updatedAt: String? = null
)
