package com.edusync.app.domain.mapper

import com.edusync.app.data.local.entity.UserEntity
import com.edusync.app.data.remote.dto.UserProfileDto
import com.edusync.app.domain.model.Role
import com.edusync.app.domain.model.User
import java.time.Instant

object UserMapper {

    fun toDomain(entity: UserEntity): User {
        return User(
            id = entity.id,
            email = entity.email,
            displayName = entity.displayName,
            role = entity.role,
            deviceId = entity.deviceId,
            createdAt = entity.createdAt,
            updatedAt = entity.updatedAt
        )
    }

    fun toEntity(domain: User): UserEntity {
        return UserEntity(
            id = domain.id,
            email = domain.email,
            displayName = domain.displayName,
            role = domain.role,
            deviceId = domain.deviceId,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt
        )
    }

    fun toEntity(dto: UserProfileDto): UserEntity {
        val now = System.currentTimeMillis()
        val createdEpoch = parseIsoToEpoch(dto.createdAt, now)
        val updatedEpoch = parseIsoToEpoch(dto.updatedAt, now)

        return UserEntity(
            id = dto.id,
            email = dto.email,
            displayName = dto.displayName,
            role = Role.fromString(dto.role),
            deviceId = dto.deviceId ?: "",
            createdAt = createdEpoch,
            updatedAt = updatedEpoch
        )
    }

    fun toDto(domain: User): UserProfileDto {
        return UserProfileDto(
            id = domain.id,
            email = domain.email,
            displayName = domain.displayName,
            role = domain.role.name,
            deviceId = domain.deviceId,
            createdAt = Instant.ofEpochMilli(domain.createdAt).toString(),
            updatedAt = Instant.ofEpochMilli(domain.updatedAt).toString()
        )
    }

    fun parseIsoToEpoch(isoString: String?, defaultEpoch: Long): Long {
        if (isoString.isNullOrEmpty()) return defaultEpoch
        return try {
            Instant.parse(isoString).toEpochMilli()
        } catch (e: Exception) {
            defaultEpoch
        }
    }
}
