package com.edusync.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.edusync.app.ui.theme.SuccessGreen
import com.edusync.app.ui.theme.WarningAmber

@Composable
fun SyncIndicator(
    pendingCount: Int,
    isSyncing: Boolean,
    onSyncClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sync_rotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotate_angle"
    )

    Row(
        modifier = modifier
            .clickable(onClick = onSyncClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BadgedBox(
            badge = {
                if (pendingCount > 0) {
                    Badge(
                        containerColor = WarningAmber,
                        contentColor = Color.Black
                    ) {
                        Text(text = if (pendingCount > 99) "99+" else pendingCount.toString())
                    }
                }
            }
        ) {
            if (isSyncing) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Syncing in progress",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.rotate(angle)
                )
            } else if (pendingCount == 0) {
                Icon(
                    imageVector = Icons.Default.CloudDone,
                    contentDescription = "Synchronized",
                    tint = SuccessGreen
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Pending mutations",
                    tint = WarningAmber
                )
            }
        }
    }
}
