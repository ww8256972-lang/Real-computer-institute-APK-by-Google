package com.edusync.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.edusync.app.domain.model.SyncStatus

@Entity(
    tableName = "courses",
    indices = [
        Index(value = ["updated_at"]),
        Index(value = ["is_archived"]),
        Index(value = ["category"]),
        Index(value = ["sync_status"])
    ]
)
data class CourseEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    @ColumnInfo(name = "instructor_id")
    val instructorId: String?,
    val category: String,
    @ColumnInfo(name = "enrolled_count")
    val enrolledCount: Int,
    @ColumnInfo(name = "is_archived")
    val isArchived: Boolean,
    @ColumnInfo(name = "created_at")
    val createdAt: Long,
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long,
    @ColumnInfo(name = "sync_status")
    val syncStatus: SyncStatus = SyncStatus.SYNCED
)
