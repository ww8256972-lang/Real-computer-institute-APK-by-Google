package com.edusync.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.edusync.app.EduSyncApplication
import com.edusync.app.core.Resource
import kotlinx.coroutines.flow.first

class SyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? EduSyncApplication ?: return Result.failure()
        val syncRepo = app.container.syncRepository

        return try {
            val result = syncRepo.synchronizeAll().first { it !is Resource.Loading }
            when (result) {
                is Resource.Success -> Result.success()
                is Resource.Error -> {
                    if (runAttemptCount < 3) {
                        Result.retry()
                    } else {
                        Result.failure()
                    }
                }
                else -> Result.failure()
            }
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}
