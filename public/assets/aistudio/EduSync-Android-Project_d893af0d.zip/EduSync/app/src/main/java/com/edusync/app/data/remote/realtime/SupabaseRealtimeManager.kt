package com.edusync.app.data.remote.realtime

import com.edusync.app.core.Constants
import com.edusync.app.data.remote.SupabaseConfig
import com.edusync.app.data.remote.dto.AssignmentDto
import com.edusync.app.data.remote.dto.CourseDto
import com.edusync.app.data.remote.dto.SubmissionDto
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.realtime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

sealed interface RealtimeSyncEvent {
    data class CourseChanged(val action: PostgresAction, val course: CourseDto?) : RealtimeSyncEvent
    data class AssignmentChanged(val action: PostgresAction, val assignment: AssignmentDto?) : RealtimeSyncEvent
    data class SubmissionChanged(val action: PostgresAction, val submission: SubmissionDto?) : RealtimeSyncEvent
    data class StatusChanged(val isConnected: Boolean, val message: String? = null) : RealtimeSyncEvent
}

class SupabaseRealtimeManager(
    private val supabase: io.github.jan.supabase.SupabaseClient = SupabaseConfig.client
) {
    private val _events = MutableSharedFlow<RealtimeSyncEvent>(extraBufferCapacity = 64)
    val events: Flow<RealtimeSyncEvent> = _events.asSharedFlow()

    private var subscriptionJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    fun startListening() {
        if (subscriptionJob != null && subscriptionJob?.isActive == true) return

        subscriptionJob = scope.launch {
            try {
                val channel = supabase.realtime.channel("public-db-changes")

                // Subscribe to courses table
                val courseFlow = channel.postgresChangeFlow<PostgresAction>(schema = "public") {
                    table = Constants.TABLE_COURSES
                }
                courseFlow.onEach { action ->
                    val courseDto = when (action) {
                        is PostgresAction.Insert -> action.decodeRecordOrNull<CourseDto>()
                        is PostgresAction.Update -> action.decodeRecordOrNull<CourseDto>()
                        is PostgresAction.Delete -> action.decodeOldRecordOrNull<CourseDto>()
                        else -> null
                    }
                    _events.emit(RealtimeSyncEvent.CourseChanged(action, courseDto))
                }.launchIn(this)

                // Subscribe to assignments table
                val assignmentFlow = channel.postgresChangeFlow<PostgresAction>(schema = "public") {
                    table = Constants.TABLE_ASSIGNMENTS
                }
                assignmentFlow.onEach { action ->
                    val assignmentDto = when (action) {
                        is PostgresAction.Insert -> action.decodeRecordOrNull<AssignmentDto>()
                        is PostgresAction.Update -> action.decodeRecordOrNull<AssignmentDto>()
                        is PostgresAction.Delete -> action.decodeOldRecordOrNull<AssignmentDto>()
                        else -> null
                    }
                    _events.emit(RealtimeSyncEvent.AssignmentChanged(action, assignmentDto))
                }.launchIn(this)

                // Subscribe to submissions table
                val submissionFlow = channel.postgresChangeFlow<PostgresAction>(schema = "public") {
                    table = Constants.TABLE_SUBMISSIONS
                }
                submissionFlow.onEach { action ->
                    val submissionDto = when (action) {
                        is PostgresAction.Insert -> action.decodeRecordOrNull<SubmissionDto>()
                        is PostgresAction.Update -> action.decodeRecordOrNull<SubmissionDto>()
                        is PostgresAction.Delete -> action.decodeOldRecordOrNull<SubmissionDto>()
                        else -> null
                    }
                    _events.emit(RealtimeSyncEvent.SubmissionChanged(action, submissionDto))
                }.launchIn(this)

                channel.subscribe(blockUntilSubscribed = false)
                _events.emit(RealtimeSyncEvent.StatusChanged(isConnected = true, message = "Realtime channel connected"))
            } catch (e: Exception) {
                _events.emit(RealtimeSyncEvent.StatusChanged(isConnected = false, message = e.message))
            }
        }
    }

    fun stopListening() {
        subscriptionJob?.cancel()
        subscriptionJob = null
    }
}
