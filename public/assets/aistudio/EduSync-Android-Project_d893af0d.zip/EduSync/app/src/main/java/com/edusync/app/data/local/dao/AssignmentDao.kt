package com.edusync.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.edusync.app.core.Constants
import com.edusync.app.data.local.entity.AssignmentEntity
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface AssignmentDao {

    @Query("SELECT * FROM assignments WHERE course_id = :courseId ORDER BY due_date ASC")
    fun observeAssignmentsByCourse(courseId: String): Flow<List<AssignmentEntity>>

    @Query("SELECT * FROM assignments ORDER BY due_date ASC")
    fun observeAllAssignments(): Flow<List<AssignmentEntity>>

    @Query("SELECT * FROM assignments WHERE id = :id LIMIT 1")
    suspend fun getAssignmentById(id: String): AssignmentEntity?

    @Query("SELECT * FROM assignments")
    suspend fun getAllAssignments(): List<AssignmentEntity>

    @Query("SELECT COUNT(*) FROM assignments")
    suspend fun getAssignmentCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(assignment: AssignmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(assignments: List<AssignmentEntity>)

    @Update
    suspend fun update(assignment: AssignmentEntity)

    @Query("UPDATE assignments SET sync_status = :status WHERE id = :id")
    suspend fun updateSyncStatus(id: String, status: SyncStatus)

    @Query("DELETE FROM assignments WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM assignments")
    suspend fun clearAll()

    @Transaction
    suspend fun upsertInChunks(assignments: List<AssignmentEntity>, chunkSize: Int = Constants.BATCH_CHUNK_SIZE) {
        assignments.chunked(chunkSize).forEach { chunk ->
            insertAll(chunk)
        }
    }
}
