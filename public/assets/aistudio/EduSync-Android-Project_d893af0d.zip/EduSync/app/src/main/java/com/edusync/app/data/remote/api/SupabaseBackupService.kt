package com.edusync.app.data.remote.api

import com.edusync.app.core.Constants
import com.edusync.app.core.Resource
import com.edusync.app.data.remote.SupabaseConfig
import com.edusync.app.data.remote.dto.BackupSnapshotDto
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order

class SupabaseBackupService(
    private val supabase: io.github.jan.supabase.SupabaseClient = SupabaseConfig.client
) {

    suspend fun uploadBackupSnapshot(snapshot: BackupSnapshotDto): Resource<Unit> {
        return try {
            supabase.postgrest[Constants.TABLE_BACKUPS].upsert(snapshot)
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to upload cloud backup", e)
        }
    }

    suspend fun getLatestBackupSnapshot(userId: String): Resource<BackupSnapshotDto?> {
        return try {
            val snapshot = supabase.postgrest[Constants.TABLE_BACKUPS]
                .select {
                    filter {
                        eq("user_id", userId)
                    }
                    order(column = "created_at", order = Order.DESCENDING)
                    limit(1)
                }
                .decodeSingleOrNull<BackupSnapshotDto>()

            Resource.Success(snapshot)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to retrieve latest backup", e)
        }
    }
}
