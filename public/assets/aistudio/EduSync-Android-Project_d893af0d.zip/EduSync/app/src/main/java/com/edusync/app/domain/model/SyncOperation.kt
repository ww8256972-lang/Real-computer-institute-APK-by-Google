package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class SyncStatus {
    SYNCED,
    PENDING_INSERT,
    PENDING_UPDATE,
    PENDING_DELETE,
    FAILED
}

@Serializable
enum class SyncOperationType {
    CREATE,
    UPDATE,
    DELETE
}

@Serializable
enum class SyncEntityType {
    COURSE,
    ASSIGNMENT,
    SUBMISSION,
    PROFILE
}

@Serializable
data class SyncQueueItem(
    val id: String,
    val entityType: SyncEntityType,
    val entityId: String,
    val operation: SyncOperationType,
    val payloadJson: String,
    val retryCount: Int,
    val createdAt: Long,
    val status: SyncStatus,
    val errorMessage: String? = null
)
