package com.edusync.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.edusync.app.domain.model.Role
import com.edusync.app.ui.admin.AdminDashboardScreen
import com.edusync.app.ui.admin.AdminViewModel
import com.edusync.app.ui.admin.BulkDataManagementScreen
import com.edusync.app.ui.auth.AuthViewModel
import com.edusync.app.ui.auth.LoginScreen
import com.edusync.app.ui.auth.RegisterScreen
import com.edusync.app.ui.settings.BackupRestoreScreen
import com.edusync.app.ui.settings.SettingsScreen
import com.edusync.app.ui.settings.SettingsViewModel
import com.edusync.app.ui.student.CourseDetailScreen
import com.edusync.app.ui.student.StudentDashboardScreen
import com.edusync.app.ui.student.StudentViewModel

@Composable
fun EduSyncNavGraph(
    navController: NavHostController,
    authViewModel: AuthViewModel,
    adminViewModel: AdminViewModel,
    studentViewModel: StudentViewModel,
    settingsViewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route,
        modifier = modifier
    ) {
        composable(Screen.Login.route) {
            LoginScreen(
                viewModel = authViewModel,
                onNavigateToRegister = {
                    navController.navigate(Screen.Register.route)
                },
                onLoginSuccess = { role ->
                    val destination = if (role == Role.ADMIN) Screen.AdminDashboard.route else Screen.StudentDashboard.route
                    navController.navigate(destination) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                viewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
                onRegisterSuccess = { role ->
                    val destination = if (role == Role.ADMIN) Screen.AdminDashboard.route else Screen.StudentDashboard.route
                    navController.navigate(destination) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }

        // Admin Routes
        composable(Screen.AdminDashboard.route) {
            AdminDashboardScreen(
                viewModel = adminViewModel,
                onNavigateToBulkManagement = {
                    navController.navigate(Screen.BulkManagement.route)
                },
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(Screen.BulkManagement.route) {
            BulkDataManagementScreen(
                viewModel = adminViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Student Routes
        composable(Screen.StudentDashboard.route) {
            StudentDashboardScreen(
                viewModel = studentViewModel,
                onCourseClick = { courseId ->
                    navController.navigate(Screen.CourseDetail.createRoute(courseId))
                },
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(
            route = Screen.CourseDetail.route,
            arguments = listOf(navArgument("courseId") { type = NavType.StringType })
        ) { backStackEntry ->
            val courseId = backStackEntry.arguments?.getString("courseId") ?: ""
            CourseDetailScreen(
                courseId = courseId,
                viewModel = studentViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Shared Routes
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToBackupRestore = {
                    navController.navigate(Screen.BackupRestore.route)
                },
                onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.BackupRestore.route) {
            BackupRestoreScreen(
                viewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
