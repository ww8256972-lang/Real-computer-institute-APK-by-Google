package com.edusync.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val PrimaryLight = Color(0xFF1E40AF) // Indigo 800
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE) // Indigo 100
val OnPrimaryContainerLight = Color(0xFF1E3A8A)

val SecondaryLight = Color(0xFF0F766E) // Teal 700
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCCFBF1) // Teal 100
val OnSecondaryContainerLight = Color(0xFF115E59)

val TertiaryLight = Color(0xFFD97706) // Amber 600
val OnTertiaryLight = Color(0xFFFFFFFF)

val BackgroundLight = Color(0xFFF8FAFC) // Slate 50
val OnBackgroundLight = Color(0xFF0F172A) // Slate 900
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)

val ErrorLight = Color(0xFFDC2626) // Red 600
val OnErrorLight = Color(0xFFFFFFFF)

// Dark Palette
val PrimaryDark = Color(0xFF60A5FA) // Blue 400
val OnPrimaryDark = Color(0xFF0F172A)
val PrimaryContainerDark = Color(0xFF1E3A8A) // Blue 900
val OnPrimaryContainerDark = Color(0xFFDBEAFE)

val SecondaryDark = Color(0xFF2DD4BF) // Teal 400
val OnSecondaryDark = Color(0xFF042F2E)
val SecondaryContainerDark = Color(0xFF115E59) // Teal 800
val OnSecondaryContainerDark = Color(0xFFCCFBF1)

val TertiaryDark = Color(0xFFFBBF24) // Amber 400
val OnTertiaryDark = Color(0xFF451A03)

val BackgroundDark = Color(0xFF0B0F19) // Deep Midnight
val OnBackgroundDark = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF131B2E) // Surface container
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1E293B) // Slate 800
val OnSurfaceVariantDark = Color(0xFF94A3B8)

val ErrorDark = Color(0xFFF87171)
val OnErrorDark = Color(0xFF450A0A)

// Status & Accent Colors
val SuccessGreen = Color(0xFF16A34A)
val WarningAmber = Color(0xFFF59E0B)
val OfflineOrange = Color(0xFFEA580C)
