package com.edusync.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.edusync.app.core.Constants
import com.edusync.app.data.local.dao.AssignmentDao
import com.edusync.app.data.local.dao.CourseDao
import com.edusync.app.data.local.dao.SubmissionDao
import com.edusync.app.data.local.dao.SyncQueueDao
import com.edusync.app.data.local.dao.UserDao
import com.edusync.app.data.local.entity.AssignmentEntity
import com.edusync.app.data.local.entity.CourseEntity
import com.edusync.app.data.local.entity.SubmissionEntity
import com.edusync.app.data.local.entity.SyncQueueEntity
import com.edusync.app.data.local.entity.UserEntity

@Database(
    entities = [
        UserEntity::class,
        CourseEntity::class,
        AssignmentEntity::class,
        SubmissionEntity::class,
        SyncQueueEntity::class
    ],
    version = Constants.DATABASE_VERSION,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun courseDao(): CourseDao
    abstract fun assignmentDao(): AssignmentDao
    abstract fun submissionDao(): SubmissionDao
    abstract fun syncQueueDao(): SyncQueueDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Migration from Database version 1 to version 2:
         * - Adds device_id to users table for cross-device backup tracking
         * - Adds category, enrolled_count, is_archived, and sync_status to courses
         * - Adds sync_status to assignments and submissions
         * - Creates the offline sync_queue table and high-performance indices
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Alter users
                db.execSQL("ALTER TABLE users ADD COLUMN device_id TEXT NOT NULL DEFAULT ''")

                // Alter courses
                db.execSQL("ALTER TABLE courses ADD COLUMN category TEXT NOT NULL DEFAULT 'General'")
                db.execSQL("ALTER TABLE courses ADD COLUMN enrolled_count INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE courses ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE courses ADD COLUMN sync_status TEXT NOT NULL DEFAULT 'SYNCED'")

                // Alter assignments & submissions
                db.execSQL("ALTER TABLE assignments ADD COLUMN sync_status TEXT NOT NULL DEFAULT 'SYNCED'")
                db.execSQL("ALTER TABLE submissions ADD COLUMN sync_status TEXT NOT NULL DEFAULT 'SYNCED'")

                // Create sync_queue table
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS sync_queue (
                        id TEXT PRIMARY KEY NOT NULL,
                        entity_type TEXT NOT NULL,
                        entity_id TEXT NOT NULL,
                        operation TEXT NOT NULL,
                        payload_json TEXT NOT NULL,
                        retry_count INTEGER NOT NULL DEFAULT 0,
                        created_at INTEGER NOT NULL,
                        status TEXT NOT NULL DEFAULT 'PENDING_INSERT',
                        error_message TEXT
                    )
                    """.trimIndent()
                )

                // Performance Indices
                db.execSQL("CREATE INDEX IF NOT EXISTS index_courses_updated_at ON courses(updated_at)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_courses_is_archived ON courses(is_archived)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assignments_due_date ON assignments(due_date)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_queue_status_created_at ON sync_queue(status, created_at)")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    Constants.DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
