package com.edusync.app.data.repository

import com.edusync.app.core.DispatcherProvider
import com.edusync.app.core.Resource
import com.edusync.app.core.TokenManager
import com.edusync.app.data.local.dao.UserDao
import com.edusync.app.data.remote.api.SupabaseAuthService
import com.edusync.app.domain.mapper.UserMapper
import com.edusync.app.domain.model.Role
import com.edusync.app.domain.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

interface AuthRepository {
    val currentUser: StateFlow<User?>
    fun signIn(email: String, password: String): Flow<Resource<User>>
    fun signUp(email: String, password: String, displayName: String, role: Role): Flow<Resource<User>>
    fun signOut(): Flow<Resource<Unit>>
    fun restoreSession(): Flow<Resource<User?>>
}

class AuthRepositoryImpl(
    private val authService: SupabaseAuthService,
    private val userDao: UserDao,
    private val tokenManager: TokenManager,
    private val dispatchers: DispatcherProvider
) : AuthRepository {

    private val _currentUser = MutableStateFlow<User?>(null)
    override val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    override fun signIn(email: String, password: String): Flow<Resource<User>> = flow {
        emit(Resource.Loading)
        when (val result = authService.signIn(email, password)) {
            is Resource.Success -> {
                val profileDto = result.data
                val entity = UserMapper.toEntity(profileDto)
                userDao.insertOrUpdate(entity)
                val domainUser = UserMapper.toDomain(entity)

                tokenManager.saveAuthTokens(
                    accessToken = "session_active",
                    refreshToken = null,
                    userId = domainUser.id,
                    role = domainUser.role.name
                )
                _currentUser.value = domainUser
                emit(Resource.Success(domainUser))
            }
            is Resource.Error -> {
                // If offline, check if user exists locally in Room cache
                val localUser = withContext(dispatchers.io) {
                    val userId = tokenManager.getUserId()
                    if (userId != null) userDao.getUserById(userId) else null
                }
                if (localUser != null && localUser.email.equals(email, ignoreCase = true)) {
                    val user = UserMapper.toDomain(localUser)
                    _currentUser.value = user
                    emit(Resource.Success(user))
                } else {
                    emit(Resource.Error(result.message, result.cause))
                }
            }
            Resource.Loading, Resource.Idle -> Unit
        }
    }.flowOn(dispatchers.io)

    override fun signUp(
        email: String,
        password: String,
        displayName: String,
        role: Role
    ): Flow<Resource<User>> = flow {
        emit(Resource.Loading)
        val deviceId = tokenManager.getDeviceId()
        when (val result = authService.signUp(email, password, displayName, role.name, deviceId)) {
            is Resource.Success -> {
                val profileDto = result.data
                val entity = UserMapper.toEntity(profileDto)
                userDao.insertOrUpdate(entity)
                val domainUser = UserMapper.toDomain(entity)

                tokenManager.saveAuthTokens(
                    accessToken = "session_active",
                    refreshToken = null,
                    userId = domainUser.id,
                    role = domainUser.role.name
                )
                _currentUser.value = domainUser
                emit(Resource.Success(domainUser))
            }
            is Resource.Error -> {
                emit(Resource.Error(result.message, result.cause))
            }
            Resource.Loading, Resource.Idle -> Unit
        }
    }.flowOn(dispatchers.io)

    override fun signOut(): Flow<Resource<Unit>> = flow {
        emit(Resource.Loading)
        authService.signOut()
        tokenManager.clearSession()
        _currentUser.value = null
        emit(Resource.Success(Unit))
    }.flowOn(dispatchers.io)

    override fun restoreSession(): Flow<Resource<User?>> = flow {
        emit(Resource.Loading)
        val savedUserId = tokenManager.getUserId()
        if (savedUserId.isNullOrEmpty()) {
            _currentUser.value = null
            emit(Resource.Success(null))
            return@flow
        }

        // Try local cache first for instant startup
        val cachedUserEntity = userDao.getUserById(savedUserId)
        if (cachedUserEntity != null) {
            val cachedUser = UserMapper.toDomain(cachedUserEntity)
            _currentUser.value = cachedUser
            emit(Resource.Success(cachedUser))
        }

        // Verify/refresh against remote
        when (val remoteResult = authService.getProfile(savedUserId)) {
            is Resource.Success -> {
                val updatedEntity = UserMapper.toEntity(remoteResult.data)
                userDao.insertOrUpdate(updatedEntity)
                val updatedUser = UserMapper.toDomain(updatedEntity)
                _currentUser.value = updatedUser
                emit(Resource.Success(updatedUser))
            }
            is Resource.Error -> {
                if (cachedUserEntity == null) {
                    emit(Resource.Error(remoteResult.message, remoteResult.cause))
                }
            }
            Resource.Loading, Resource.Idle -> Unit
        }
    }.flowOn(dispatchers.io)
}
