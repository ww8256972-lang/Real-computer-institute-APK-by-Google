package com.edusync.app.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CourseDto(
    @SerialName("id")
    val id: String,
    @SerialName("title")
    val title: String,
    @SerialName("description")
    val description: String = "",
    @SerialName("instructor_id")
    val instructorId: String? = null,
    @SerialName("category")
    val category: String = "General",
    @SerialName("enrolled_count")
    val enrolledCount: Int = 0,
    @SerialName("is_archived")
    val isArchived: Boolean = false,
    @SerialName("created_at")
    val createdAt: String? = null,
    @SerialName("updated_at")
    val updatedAt: String? = null
)
