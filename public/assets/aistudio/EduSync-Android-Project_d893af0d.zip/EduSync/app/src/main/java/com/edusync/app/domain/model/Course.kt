package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class Course(
    val id: String,
    val title: String,
    val description: String,
    val instructorId: String?,
    val category: String,
    val enrolledCount: Int,
    val isArchived: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val syncStatus: SyncStatus = SyncStatus.SYNCED
)
