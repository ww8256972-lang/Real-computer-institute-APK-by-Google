package com.edusync.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.edusync.app.data.local.entity.SyncQueueEntity
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncQueueDao {

    @Query("SELECT * FROM sync_queue WHERE status IN ('PENDING_INSERT', 'PENDING_UPDATE', 'PENDING_DELETE', 'FAILED') ORDER BY created_at ASC")
    suspend fun getPendingItems(): List<SyncQueueEntity>

    @Query("SELECT * FROM sync_queue ORDER BY created_at DESC")
    fun observeAllItems(): Flow<List<SyncQueueEntity>>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status != 'SYNCED'")
    fun observePendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status != 'SYNCED'")
    suspend fun getPendingCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: SyncQueueEntity)

    @Update
    suspend fun update(item: SyncQueueEntity)

    @Query("UPDATE sync_queue SET status = :status, error_message = :errorMessage WHERE id = :id")
    suspend fun updateStatus(id: String, status: SyncStatus, errorMessage: String? = null)

    @Query("UPDATE sync_queue SET retry_count = retry_count + 1, status = :status, error_message = :errorMessage WHERE id = :id")
    suspend fun recordRetry(id: String, status: SyncStatus, errorMessage: String?)

    @Query("DELETE FROM sync_queue WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM sync_queue WHERE status = 'SYNCED'")
    suspend fun deleteSyncedItems()

    @Query("DELETE FROM sync_queue")
    suspend fun clearAll()
}
