package com.edusync.app.core

object Constants {
    // Supabase Configuration
    // In production, these can be set via BuildConfig or local.properties
    const val SUPABASE_URL = "https://your-project-id.supabase.co"
    const val SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.dummy_anon_key_for_edusync"

    // Tables
    const val TABLE_PROFILES = "profiles"
    const val TABLE_COURSES = "courses"
    const val TABLE_ASSIGNMENTS = "assignments"
    const val TABLE_SUBMISSIONS = "submissions"
    const val TABLE_BACKUPS = "backups"

    // Local Database
    const val DATABASE_NAME = "edusync_database.db"
    const val DATABASE_VERSION = 2

    // Sync Configuration
    const val SYNC_WORK_NAME = "EduSyncCloudSyncWork"
    const val BACKUP_WORK_NAME = "EduSyncAutoBackupWork"
    const val SYNC_INTERVAL_MINUTES = 15L
    const val BATCH_CHUNK_SIZE = 250
    const val MAX_RETRY_ATTEMPTS = 5
    const val INITIAL_BACKOFF_MILLIS = 3000L

    // Preferences
    const val PREFS_FILE = "edusync_secure_prefs"
    const val KEY_AUTH_TOKEN = "auth_token"
    const val KEY_REFRESH_TOKEN = "refresh_token"
    const val KEY_USER_ID = "user_id"
    const val KEY_USER_ROLE = "user_role"
    const val KEY_DEVICE_ID = "device_id"
    const val KEY_LAST_SYNC_TIMESTAMP = "last_sync_timestamp"
    const val KEY_LAST_BACKUP_TIMESTAMP = "last_backup_timestamp"
}
