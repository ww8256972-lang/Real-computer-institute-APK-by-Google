package com.edusync.app.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SubmissionDto(
    @SerialName("id")
    val id: String,
    @SerialName("assignment_id")
    val assignmentId: String,
    @SerialName("student_id")
    val studentId: String,
    @SerialName("content")
    val content: String,
    @SerialName("score")
    val score: Int? = null,
    @SerialName("feedback")
    val feedback: String? = null,
    @SerialName("status")
    val status: String = "SUBMITTED",
    @SerialName("submitted_at")
    val submittedAt: String? = null,
    @SerialName("updated_at")
    val updatedAt: String? = null
)
