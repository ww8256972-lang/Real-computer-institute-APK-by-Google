package com.edusync.app.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.data.repository.AssignmentRepository
import com.edusync.app.data.repository.CourseRepository
import com.edusync.app.data.repository.SyncRepository
import com.edusync.app.domain.model.Assignment
import com.edusync.app.domain.model.Course
import com.edusync.app.domain.model.Submission
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class AdminUiState(
    val courses: List<Course> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val isSyncing: Boolean = false,
    val pendingSyncCount: Int = 0,
    val isOffline: Boolean = false,
    val totalCourseCount: Int = 0,
    val message: String? = null,
    val error: String? = null
)

class AdminViewModel(
    private val courseRepository: CourseRepository,
    private val assignmentRepository: AssignmentRepository,
    private val syncRepository: SyncRepository,
    private val networkMonitor: NetworkMonitor
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        // Observe courses with reactive search filter
        _searchQuery.onEach { query ->
            courseRepository.observeCourses(query).onEach { courses ->
                _uiState.update { it.copy(courses = courses, totalCourseCount = courses.size) }
            }.launchIn(viewModelScope)
        }.launchIn(viewModelScope)

        // Observe network state
        networkMonitor.isOnline.onEach { online ->
            _uiState.update { it.copy(isOffline = !online) }
        }.launchIn(viewModelScope)

        // Observe pending sync items count
        syncRepository.observePendingSyncCount().onEach { count ->
            _uiState.update { it.copy(pendingSyncCount = count) }
        }.launchIn(viewModelScope)
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun createCourse(title: String, description: String, category: String) {
        if (title.isBlank()) {
            _uiState.update { it.copy(error = "Course title cannot be empty") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val course = Course(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                description = description.trim(),
                instructorId = null,
                category = category.ifBlank { "General" },
                enrolledCount = 0,
                isArchived = false,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            val result = courseRepository.createCourse(course)
            _uiState.update {
                it.copy(
                    isLoading = false,
                    message = if (result is Resource.Success) "Course created successfully" else null,
                    error = if (result is Resource.Error) result.message else null
                )
            }
        }
    }

    fun archiveCourse(courseId: String) {
        viewModelScope.launch {
            courseRepository.deleteCourse(courseId)
        }
    }

    fun addAssignment(courseId: String, title: String, description: String, dueDate: Long, points: Int) {
        viewModelScope.launch {
            val assignment = Assignment(
                id = UUID.randomUUID().toString(),
                courseId = courseId,
                title = title.trim(),
                description = description.trim(),
                dueDate = dueDate,
                maxPoints = points,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            assignmentRepository.createAssignment(assignment)
        }
    }

    fun triggerSync() {
        syncRepository.synchronizeAll().onEach { resource ->
            when (resource) {
                is Resource.Loading -> _uiState.update { it.copy(isSyncing = true) }
                is Resource.Success -> {
                    val res = resource.data
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            message = "Synced: ${res.uploadedCount} uploaded, ${res.downloadedCount} updated"
                        )
                    }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(isSyncing = false, error = resource.message)
                }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    /**
     * Benchmark and stress-test: Generates and imports 1,000 course records in bounded chunks.
     * Demonstrates high-performance batch handling without SQLite variable limit crashes.
     */
    fun runBulkDataStressTest(count: Int = 1000) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = "Generating $count records...") }
            val now = System.currentTimeMillis()
            val bulkCourses = (1..count).map { index ->
                Course(
                    id = "bulk_${UUID.randomUUID()}",
                    title = "Course #$index: Advanced Systems & Algorithms",
                    description = "Comprehensive stress testing curriculum module $index with offline storage benchmarks.",
                    instructorId = null,
                    category = if (index % 2 == 0) "Computer Science" else "Data Science",
                    enrolledCount = (index * 7) % 150,
                    isArchived = false,
                    createdAt = now - index * 60000L,
                    updatedAt = now
                )
            }

            val startTime = System.currentTimeMillis()
            val result = courseRepository.bulkImportCourses(bulkCourses)
            val duration = System.currentTimeMillis() - startTime

            _uiState.update {
                it.copy(
                    isLoading = false,
                    message = "Successfully imported $count records in ${duration}ms via chunked Room transactions."
                )
            }
        }
    }

    fun dismissMessage() {
        _uiState.update { it.copy(message = null, error = null) }
    }
}
