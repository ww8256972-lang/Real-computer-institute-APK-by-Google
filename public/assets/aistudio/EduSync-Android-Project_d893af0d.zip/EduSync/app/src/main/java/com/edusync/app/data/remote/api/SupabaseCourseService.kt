package com.edusync.app.data.remote.api

import com.edusync.app.core.Constants
import com.edusync.app.core.Resource
import com.edusync.app.data.remote.SupabaseConfig
import com.edusync.app.data.remote.dto.AssignmentDto
import com.edusync.app.data.remote.dto.CourseDto
import com.edusync.app.data.remote.dto.SubmissionDto
import io.github.jan.supabase.postgrest.postgrest

class SupabaseCourseService(
    private val supabase: io.github.jan.supabase.SupabaseClient = SupabaseConfig.client
) {

    suspend fun fetchAllCourses(sinceTimestamp: String? = null): Resource<List<CourseDto>> {
        return try {
            val response = supabase.postgrest[Constants.TABLE_COURSES].select {
                if (sinceTimestamp != null) {
                    filter {
                        gt("updated_at", sinceTimestamp)
                    }
                }
            }.decodeList<CourseDto>()
            Resource.Success(response)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch courses from Supabase", e)
        }
    }

    suspend fun upsertCourse(course: CourseDto): Resource<CourseDto> {
        return try {
            supabase.postgrest[Constants.TABLE_COURSES].upsert(course)
            Resource.Success(course)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to upsert course", e)
        }
    }

    suspend fun upsertCoursesBatch(courses: List<CourseDto>): Resource<Int> {
        return try {
            courses.chunked(Constants.BATCH_CHUNK_SIZE).forEach { chunk ->
                supabase.postgrest[Constants.TABLE_COURSES].upsert(chunk)
            }
            Resource.Success(courses.size)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Batch courses upsert failed", e)
        }
    }

    suspend fun deleteCourse(courseId: String): Resource<Unit> {
        return try {
            supabase.postgrest[Constants.TABLE_COURSES].delete {
                filter { eq("id", courseId) }
            }
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to delete course", e)
        }
    }

    suspend fun fetchAssignments(sinceTimestamp: String? = null): Resource<List<AssignmentDto>> {
        return try {
            val response = supabase.postgrest[Constants.TABLE_ASSIGNMENTS].select {
                if (sinceTimestamp != null) {
                    filter { gt("updated_at", sinceTimestamp) }
                }
            }.decodeList<AssignmentDto>()
            Resource.Success(response)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch assignments", e)
        }
    }

    suspend fun upsertAssignment(assignment: AssignmentDto): Resource<AssignmentDto> {
        return try {
            supabase.postgrest[Constants.TABLE_ASSIGNMENTS].upsert(assignment)
            Resource.Success(assignment)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to upsert assignment", e)
        }
    }

    suspend fun deleteAssignment(assignmentId: String): Resource<Unit> {
        return try {
            supabase.postgrest[Constants.TABLE_ASSIGNMENTS].delete {
                filter { eq("id", assignmentId) }
            }
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to delete assignment", e)
        }
    }

    suspend fun fetchSubmissions(studentId: String? = null, sinceTimestamp: String? = null): Resource<List<SubmissionDto>> {
        return try {
            val response = supabase.postgrest[Constants.TABLE_SUBMISSIONS].select {
                filter {
                    if (studentId != null) eq("student_id", studentId)
                    if (sinceTimestamp != null) gt("updated_at", sinceTimestamp)
                }
            }.decodeList<SubmissionDto>()
            Resource.Success(response)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch submissions", e)
        }
    }

    suspend fun upsertSubmission(submission: SubmissionDto): Resource<SubmissionDto> {
        return try {
            supabase.postgrest[Constants.TABLE_SUBMISSIONS].upsert(submission)
            Resource.Success(submission)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to upsert submission", e)
        }
    }
}
