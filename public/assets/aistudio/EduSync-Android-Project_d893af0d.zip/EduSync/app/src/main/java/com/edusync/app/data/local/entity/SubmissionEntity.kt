package com.edusync.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.edusync.app.domain.model.SubmissionStatus
import com.edusync.app.domain.model.SyncStatus

@Entity(
    tableName = "submissions",
    foreignKeys = [
        ForeignKey(
            entity = AssignmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["assignment_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["assignment_id", "student_id"], unique = true),
        Index(value = ["student_id"]),
        Index(value = ["status"]),
        Index(value = ["updated_at"]),
        Index(value = ["sync_status"])
    ]
)
data class SubmissionEntity(
    @PrimaryKey
    val id: String,
    @ColumnInfo(name = "assignment_id")
    val assignmentId: String,
    @ColumnInfo(name = "student_id")
    val studentId: String,
    val content: String,
    val score: Int?,
    val feedback: String?,
    val status: SubmissionStatus,
    @ColumnInfo(name = "submitted_at")
    val submittedAt: Long,
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long,
    @ColumnInfo(name = "sync_status")
    val syncStatus: SyncStatus = SyncStatus.SYNCED
)
