package com.edusync.app.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edusync.app.core.Resource
import com.edusync.app.data.repository.AuthRepository
import com.edusync.app.domain.model.Role
import com.edusync.app.domain.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update

data class AuthUiState(
    val isLoading: Boolean = false,
    val user: User? = null,
    val error: String? = null,
    val isSessionChecked: Boolean = false
)

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        restoreSession()
    }

    fun restoreSession() {
        authRepository.restoreSession().onEach { resource ->
            when (resource) {
                is Resource.Loading -> _uiState.update { it.copy(isLoading = true) }
                is Resource.Success -> _uiState.update {
                    it.copy(isLoading = false, user = resource.data, isSessionChecked = true)
                }
                is Resource.Error -> _uiState.update {
                    it.copy(isLoading = false, user = null, isSessionChecked = true)
                }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.update { it.copy(error = "Please enter valid email and password") }
            return
        }

        authRepository.signIn(email.trim(), password).onEach { resource ->
            when (resource) {
                is Resource.Loading -> _uiState.update { it.copy(isLoading = true, error = null) }
                is Resource.Success -> _uiState.update { it.copy(isLoading = false, user = resource.data, error = null) }
                is Resource.Error -> _uiState.update { it.copy(isLoading = false, error = resource.message) }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun register(email: String, password: String, displayName: String, role: Role) {
        if (email.isBlank() || password.length < 6 || displayName.isBlank()) {
            _uiState.update { it.copy(error = "Please fill all fields (password must be at least 6 characters)") }
            return
        }

        authRepository.signUp(email.trim(), password, displayName.trim(), role).onEach { resource ->
            when (resource) {
                is Resource.Loading -> _uiState.update { it.copy(isLoading = true, error = null) }
                is Resource.Success -> _uiState.update { it.copy(isLoading = false, user = resource.data, error = null) }
                is Resource.Error -> _uiState.update { it.copy(isLoading = false, error = resource.message) }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun logout() {
        authRepository.signOut().onEach {
            _uiState.update { it.copy(user = null) }
        }.launchIn(viewModelScope)
    }
}
