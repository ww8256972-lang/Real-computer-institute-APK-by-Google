package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class Role {
    ADMIN,
    STUDENT;

    val isAdmin: Boolean get() = this == ADMIN
    val isStudent: Boolean get() = this == STUDENT

    companion object {
        fun fromString(value: String?): Role {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: STUDENT
        }
    }
}
