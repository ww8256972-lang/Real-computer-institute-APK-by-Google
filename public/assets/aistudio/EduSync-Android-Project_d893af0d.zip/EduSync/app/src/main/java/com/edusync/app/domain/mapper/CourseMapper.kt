package com.edusync.app.domain.mapper

import com.edusync.app.data.local.entity.CourseEntity
import com.edusync.app.data.remote.dto.CourseDto
import com.edusync.app.domain.model.Course
import com.edusync.app.domain.model.SyncStatus
import java.time.Instant

object CourseMapper {

    fun toDomain(entity: CourseEntity): Course {
        return Course(
            id = entity.id,
            title = entity.title,
            description = entity.description,
            instructorId = entity.instructorId,
            category = entity.category,
            enrolledCount = entity.enrolledCount,
            isArchived = entity.isArchived,
            createdAt = entity.createdAt,
            updatedAt = entity.updatedAt,
            syncStatus = entity.syncStatus
        )
    }

    fun toEntity(domain: Course, syncStatus: SyncStatus? = null): CourseEntity {
        return CourseEntity(
            id = domain.id,
            title = domain.title,
            description = domain.description,
            instructorId = domain.instructorId,
            category = domain.category,
            enrolledCount = domain.enrolledCount,
            isArchived = domain.isArchived,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt,
            syncStatus = syncStatus ?: domain.syncStatus
        )
    }

    fun toEntity(dto: CourseDto, syncStatus: SyncStatus = SyncStatus.SYNCED): CourseEntity {
        val now = System.currentTimeMillis()
        val createdEpoch = UserMapper.parseIsoToEpoch(dto.createdAt, now)
        val updatedEpoch = UserMapper.parseIsoToEpoch(dto.updatedAt, now)

        return CourseEntity(
            id = dto.id,
            title = dto.title,
            description = dto.description,
            instructorId = dto.instructorId,
            category = dto.category,
            enrolledCount = dto.enrolledCount,
            isArchived = dto.isArchived,
            createdAt = createdEpoch,
            updatedAt = updatedEpoch,
            syncStatus = syncStatus
        )
    }

    fun toDto(domain: Course): CourseDto {
        return CourseDto(
            id = domain.id,
            title = domain.title,
            description = domain.description,
            instructorId = domain.instructorId,
            category = domain.category,
            enrolledCount = domain.enrolledCount,
            isArchived = domain.isArchived,
            createdAt = Instant.ofEpochMilli(domain.createdAt).toString(),
            updatedAt = Instant.ofEpochMilli(domain.updatedAt).toString()
        )
    }
}
