package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class BackupSnapshot(
    val id: String,
    val userId: String,
    val deviceId: String,
    val schemaVersion: Int,
    val timestamp: Long,
    val courses: List<Course>,
    val assignments: List<Assignment>,
    val submissions: List<Submission>,
    val checksum: String
)
