package com.edusync.app.ui.navigation

sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object Register : Screen("register")

    // Admin Routes
    data object AdminDashboard : Screen("admin_dashboard")
    data object BulkManagement : Screen("bulk_management")

    // Student Routes
    data object StudentDashboard : Screen("student_dashboard")
    data object CourseDetail : Screen("course_detail/{courseId}") {
        fun createRoute(courseId: String): String = "course_detail/$courseId"
    }

    // Shared Routes
    data object Settings : Screen("settings")
    data object BackupRestore : Screen("backup_restore")
}
