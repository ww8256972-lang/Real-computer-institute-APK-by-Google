package com.edusync.app.data.repository

import com.edusync.app.core.Constants
import com.edusync.app.core.DispatcherProvider
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.core.TokenManager
import com.edusync.app.data.local.dao.AssignmentDao
import com.edusync.app.data.local.dao.CourseDao
import com.edusync.app.data.local.dao.SubmissionDao
import com.edusync.app.data.local.dao.SyncQueueDao
import com.edusync.app.data.remote.api.SupabaseCourseService
import com.edusync.app.domain.mapper.AssignmentMapper
import com.edusync.app.domain.mapper.CourseMapper
import com.edusync.app.domain.mapper.SubmissionMapper
import com.edusync.app.domain.model.Assignment
import com.edusync.app.domain.model.Course
import com.edusync.app.domain.model.Submission
import com.edusync.app.domain.model.SyncEntityType
import com.edusync.app.domain.model.SyncOperationType
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

data class SyncResult(
    val uploadedCount: Int,
    val downloadedCount: Int,
    val failedCount: Int,
    val timestamp: Long
)

interface SyncRepository {
    fun observePendingSyncCount(): Flow<Int>
    suspend fun getPendingSyncCount(): Int
    fun synchronizeAll(): Flow<Resource<SyncResult>>
}

class SyncRepositoryImpl(
    private val syncQueueDao: SyncQueueDao,
    private val courseDao: CourseDao,
    private val assignmentDao: AssignmentDao,
    private val submissionDao: SubmissionDao,
    private val courseService: SupabaseCourseService,
    private val networkMonitor: NetworkMonitor,
    private val tokenManager: TokenManager,
    private val dispatchers: DispatcherProvider
) : SyncRepository {

    private val json = Json { ignoreUnknownKeys = true }

    override fun observePendingSyncCount(): Flow<Int> = syncQueueDao.observePendingCount().flowOn(dispatchers.io)

    override suspend fun getPendingSyncCount(): Int = withContext(dispatchers.io) {
        syncQueueDao.getPendingCount()
    }

    override fun synchronizeAll(): Flow<Resource<SyncResult>> = flow {
        emit(Resource.Loading)

        if (!networkMonitor.isCurrentlyConnected()) {
            emit(Resource.Error("Device is offline. Queued mutations will sync when connectivity resumes."))
            return@flow
        }

        var uploaded = 0
        var failed = 0
        var downloaded = 0

        // 1. Process Outbound Sync Queue (Push offline changes to Supabase)
        val pendingQueue = syncQueueDao.getPendingItems()
        for (item in pendingQueue) {
            try {
                val success = when (item.entityType) {
                    SyncEntityType.COURSE -> processCourseItem(item.entityId, item.operation, item.payloadJson)
                    SyncEntityType.ASSIGNMENT -> processAssignmentItem(item.entityId, item.operation, item.payloadJson)
                    SyncEntityType.SUBMISSION -> processSubmissionItem(item.entityId, item.operation, item.payloadJson)
                    SyncEntityType.PROFILE -> true
                }

                if (success) {
                    syncQueueDao.deleteById(item.id)
                    uploaded++
                } else {
                    handleSyncFailure(item.id, item.retryCount, "Remote operation rejected")
                    failed++
                }
            } catch (e: Exception) {
                handleSyncFailure(item.id, item.retryCount, e.message)
                failed++
                // Exponential backoff pause between consecutive errors
                val backoff = (Constants.INITIAL_BACKOFF_MILLIS * (1 shl (item.retryCount.coerceAtMost(4)))).coerceAtMost(30000L)
                delay(backoff)
            }
        }

        // 2. Process Inbound Sync (Pull remote changes from Supabase)
        try {
            when (val coursesResult = courseService.fetchAllCourses()) {
                is Resource.Success -> {
                    val remoteCourses = coursesResult.data.map { CourseMapper.toEntity(it) }
                    courseDao.upsertInChunks(remoteCourses)
                    downloaded += remoteCourses.size
                }
                else -> Unit
            }

            when (val assignmentsResult = courseService.fetchAssignments()) {
                is Resource.Success -> {
                    val remoteAssignments = assignmentsResult.data.map { AssignmentMapper.toEntity(it) }
                    assignmentDao.upsertInChunks(remoteAssignments)
                    downloaded += remoteAssignments.size
                }
                else -> Unit
            }

            when (val submissionsResult = courseService.fetchSubmissions()) {
                is Resource.Success -> {
                    val remoteSubmissions = submissionsResult.data.map { SubmissionMapper.toEntity(it) }
                    submissionDao.upsertInChunks(remoteSubmissions)
                    downloaded += remoteSubmissions.size
                }
                else -> Unit
            }
        } catch (e: Exception) {
            // Partial sync is acceptable; report download failures gracefully
        }

        val now = System.currentTimeMillis()
        tokenManager.setLastSyncTime(now)

        emit(
            Resource.Success(
                SyncResult(
                    uploadedCount = uploaded,
                    downloadedCount = downloaded,
                    failedCount = failed,
                    timestamp = now
                )
            )
        )
    }.flowOn(dispatchers.io)

    private suspend fun processCourseItem(id: String, operation: SyncOperationType, payload: String): Boolean {
        return when (operation) {
            SyncOperationType.CREATE, SyncOperationType.UPDATE -> {
                val course = json.decodeFromString<Course>(payload)
                val dto = CourseMapper.toDto(course)
                when (courseService.upsertCourse(dto)) {
                    is Resource.Success -> {
                        courseDao.updateSyncStatus(id, SyncStatus.SYNCED)
                        true
                    }
                    else -> false
                }
            }
            SyncOperationType.DELETE -> {
                when (courseService.deleteCourse(id)) {
                    is Resource.Success -> {
                        courseDao.deleteById(id)
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private suspend fun processAssignmentItem(id: String, operation: SyncOperationType, payload: String): Boolean {
        return when (operation) {
            SyncOperationType.CREATE, SyncOperationType.UPDATE -> {
                val assignment = json.decodeFromString<Assignment>(payload)
                val dto = AssignmentMapper.toDto(assignment)
                when (courseService.upsertAssignment(dto)) {
                    is Resource.Success -> {
                        assignmentDao.updateSyncStatus(id, SyncStatus.SYNCED)
                        true
                    }
                    else -> false
                }
            }
            SyncOperationType.DELETE -> {
                when (courseService.deleteAssignment(id)) {
                    is Resource.Success -> {
                        assignmentDao.deleteById(id)
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private suspend fun processSubmissionItem(id: String, operation: SyncOperationType, payload: String): Boolean {
        val submission = json.decodeFromString<Submission>(payload)
        val dto = SubmissionMapper.toDto(submission)
        return when (courseService.upsertSubmission(dto)) {
            is Resource.Success -> {
                submissionDao.updateSyncStatus(id, SyncStatus.SYNCED)
                true
            }
            else -> false
        }
    }

    private suspend fun handleSyncFailure(id: String, currentRetries: Int, error: String?) {
        if (currentRetries + 1 >= Constants.MAX_RETRY_ATTEMPTS) {
            syncQueueDao.updateStatus(id, SyncStatus.FAILED, "Max retries exceeded: $error")
        } else {
            syncQueueDao.recordRetry(id, SyncStatus.FAILED, error)
        }
    }
}
