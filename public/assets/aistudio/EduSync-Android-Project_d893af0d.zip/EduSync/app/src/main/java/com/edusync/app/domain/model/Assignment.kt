package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class Assignment(
    val id: String,
    val courseId: String,
    val title: String,
    val description: String,
    val dueDate: Long,
    val maxPoints: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val syncStatus: SyncStatus = SyncStatus.SYNCED
)
