package com.edusync.app.data.remote

import com.edusync.app.core.Constants
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.realtime.realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage

object SupabaseConfig {

    @Volatile
    private var clientInstance: SupabaseClient? = null

    fun getClient(
        supabaseUrl: String = Constants.SUPABASE_URL,
        supabaseKey: String = Constants.SUPABASE_ANON_KEY
    ): SupabaseClient {
        return clientInstance ?: synchronized(this) {
            val client = createSupabaseClient(
                supabaseUrl = supabaseUrl,
                supabaseKey = supabaseKey
            ) {
                install(Auth) {
                    alwaysAutoRefresh = true
                    autoLoadFromStorage = true
                }
                install(Postgrest)
                install(Realtime)
                install(Storage)
            }
            clientInstance = client
            client
        }
    }

    val client: SupabaseClient get() = getClient()
    val auth: Auth get() = client.auth
    val postgrest: Postgrest get() = client.postgrest
    val realtime: Realtime get() = client.realtime
    val storage: Storage get() = client.storage
}
