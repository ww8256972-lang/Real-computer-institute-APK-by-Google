package com.edusync.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.edusync.app.core.Constants
import com.edusync.app.data.local.entity.CourseEntity
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseDao {

    @Query("SELECT * FROM courses WHERE is_archived = 0 ORDER BY updated_at DESC")
    fun observeActiveCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses ORDER BY updated_at DESC")
    fun observeAllCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE is_archived = 0 AND (title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%') ORDER BY updated_at DESC")
    fun searchCourses(query: String): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE id = :id LIMIT 1")
    suspend fun getCourseById(id: String): CourseEntity?

    @Query("SELECT * FROM courses WHERE id = :id LIMIT 1")
    fun observeCourseById(id: String): Flow<CourseEntity?>

    @Query("SELECT * FROM courses")
    suspend fun getAllCourses(): List<CourseEntity>

    @Query("SELECT COUNT(*) FROM courses")
    suspend fun getCourseCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(course: CourseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(courses: List<CourseEntity>)

    @Update
    suspend fun update(course: CourseEntity)

    @Query("UPDATE courses SET sync_status = :status WHERE id = :id")
    suspend fun updateSyncStatus(id: String, status: SyncStatus)

    @Query("DELETE FROM courses WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM courses")
    suspend fun clearAll()

    /**
     * Efficiently upserts thousands of course records in bounded chunks inside a single transaction.
     * Prevents SQLite maximum variable limit exceptions and memory spikes.
     */
    @Transaction
    suspend fun upsertInChunks(courses: List<CourseEntity>, chunkSize: Int = Constants.BATCH_CHUNK_SIZE) {
        courses.chunked(chunkSize).forEach { chunk ->
            insertAll(chunk)
        }
    }
}
