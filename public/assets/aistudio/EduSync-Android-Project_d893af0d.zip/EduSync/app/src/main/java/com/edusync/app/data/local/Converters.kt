package com.edusync.app.data.local

import androidx.room.TypeConverter
import com.edusync.app.domain.model.Role
import com.edusync.app.domain.model.SubmissionStatus
import com.edusync.app.domain.model.SyncEntityType
import com.edusync.app.domain.model.SyncOperationType
import com.edusync.app.domain.model.SyncStatus

class Converters {

    @TypeConverter
    fun fromRole(role: Role): String = role.name

    @TypeConverter
    fun toRole(value: String): Role = Role.fromString(value)

    @TypeConverter
    fun fromSyncStatus(status: SyncStatus): String = status.name

    @TypeConverter
    fun toSyncStatus(value: String): SyncStatus = try {
        SyncStatus.valueOf(value)
    } catch (e: Exception) {
        SyncStatus.SYNCED
    }

    @TypeConverter
    fun fromSyncOperationType(type: SyncOperationType): String = type.name

    @TypeConverter
    fun toSyncOperationType(value: String): SyncOperationType = try {
        SyncOperationType.valueOf(value)
    } catch (e: Exception) {
        SyncOperationType.UPDATE
    }

    @TypeConverter
    fun fromSyncEntityType(type: SyncEntityType): String = type.name

    @TypeConverter
    fun toSyncEntityType(value: String): SyncEntityType = try {
        SyncEntityType.valueOf(value)
    } catch (e: Exception) {
        SyncEntityType.COURSE
    }

    @TypeConverter
    fun fromSubmissionStatus(status: SubmissionStatus): String = status.name

    @TypeConverter
    fun toSubmissionStatus(value: String): SubmissionStatus = SubmissionStatus.fromString(value)
}
