package com.edusync.app.data.repository

import com.edusync.app.core.Constants
import com.edusync.app.core.DispatcherProvider
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.core.TokenManager
import com.edusync.app.data.local.dao.AssignmentDao
import com.edusync.app.data.local.dao.CourseDao
import com.edusync.app.data.local.dao.SubmissionDao
import com.edusync.app.data.remote.api.SupabaseBackupService
import com.edusync.app.data.remote.dto.BackupSnapshotDto
import com.edusync.app.domain.mapper.AssignmentMapper
import com.edusync.app.domain.mapper.CourseMapper
import com.edusync.app.domain.mapper.SubmissionMapper
import com.edusync.app.domain.model.BackupSnapshot
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import java.util.UUID

interface BackupRestoreRepository {
    fun createAndUploadBackup(): Flow<Resource<BackupSnapshot>>
    fun restoreLatestBackup(): Flow<Resource<BackupSnapshot>>
    fun getLastBackupTime(): Long
}

class BackupRestoreRepositoryImpl(
    private val courseDao: CourseDao,
    private val assignmentDao: AssignmentDao,
    private val submissionDao: SubmissionDao,
    private val backupService: SupabaseBackupService,
    private val tokenManager: TokenManager,
    private val networkMonitor: NetworkMonitor,
    private val dispatchers: DispatcherProvider
) : BackupRestoreRepository {

    private val json = Json {
        prettyPrint = false
        ignoreUnknownKeys = true
    }

    override fun getLastBackupTime(): Long = tokenManager.getLastSyncTime()

    override fun createAndUploadBackup(): Flow<Resource<BackupSnapshot>> = flow {
        emit(Resource.Loading)

        val userId = tokenManager.getUserId()
        if (userId.isNullOrEmpty()) {
            emit(Resource.Error("Cannot create backup: User is not authenticated"))
            return@flow
        }

        if (!networkMonitor.isCurrentlyConnected()) {
            emit(Resource.Error("Device is offline. Cloud backup requires an active internet connection."))
            return@flow
        }

        val courses = courseDao.getAllCourses().map { CourseMapper.toDomain(it) }
        val assignments = assignmentDao.getAllAssignments().map { AssignmentMapper.toDomain(it) }
        val submissions = submissionDao.getAllSubmissions().map { SubmissionMapper.toDomain(it) }

        val now = System.currentTimeMillis()
        val deviceId = tokenManager.getDeviceId()
        val snapshotId = UUID.randomUUID().toString()

        val rawPayload = json.encodeToString(
            mapOf(
                "courses" to json.encodeToString(courses),
                "assignments" to json.encodeToString(assignments),
                "submissions" to json.encodeToString(submissions)
            )
        )

        val checksum = TokenManager.computeSha256(rawPayload)

        val snapshot = BackupSnapshot(
            id = snapshotId,
            userId = userId,
            deviceId = deviceId,
            schemaVersion = Constants.DATABASE_VERSION,
            timestamp = now,
            courses = courses,
            assignments = assignments,
            submissions = submissions,
            checksum = checksum
        )

        val dto = BackupSnapshotDto(
            id = snapshotId,
            userId = userId,
            deviceId = deviceId,
            schemaVersion = Constants.DATABASE_VERSION,
            recordCount = courses.size + assignments.size + submissions.size,
            checksum = checksum,
            payload = rawPayload,
            createdAt = Instant.ofEpochMilli(now).toString()
        )

        when (val uploadResult = backupService.uploadBackupSnapshot(dto)) {
            is Resource.Success -> {
                tokenManager.setLastSyncTime(now)
                emit(Resource.Success(snapshot))
            }
            is Resource.Error -> {
                emit(Resource.Error(uploadResult.message, uploadResult.cause))
            }
            else -> emit(Resource.Error("Backup upload interrupted"))
        }
    }.flowOn(dispatchers.io)

    override fun restoreLatestBackup(): Flow<Resource<BackupSnapshot>> = flow {
        emit(Resource.Loading)

        val userId = tokenManager.getUserId()
        if (userId.isNullOrEmpty()) {
            emit(Resource.Error("Cannot restore backup: User is not authenticated"))
            return@flow
        }

        if (!networkMonitor.isCurrentlyConnected()) {
            emit(Resource.Error("Device is offline. Restoring cloud backup requires internet connectivity."))
            return@flow
        }

        when (val remoteResult = backupService.getLatestBackupSnapshot(userId)) {
            is Resource.Success -> {
                val dto = remoteResult.data
                if (dto == null) {
                    emit(Resource.Error("No existing backup snapshot found in cloud storage for this account"))
                    return@flow
                }

                // Verify integrity checksum
                val computedChecksum = TokenManager.computeSha256(dto.payload)
                if (computedChecksum != dto.checksum) {
                    emit(Resource.Error("Backup corrupted: Checksum mismatch. Restore aborted for safety."))
                    return@flow
                }

                val payloadMap = json.decodeFromString<Map<String, String>>(dto.payload)
                val courses = json.decodeFromString<List<com.edusync.app.domain.model.Course>>(payloadMap["courses"] ?: "[]")
                val assignments = json.decodeFromString<List<com.edusync.app.domain.model.Assignment>>(payloadMap["assignments"] ?: "[]")
                val submissions = json.decodeFromString<List<com.edusync.app.domain.model.Submission>>(payloadMap["submissions"] ?: "[]")

                // Atomically upsert restored entities into local Room database
                courseDao.upsertInChunks(courses.map { CourseMapper.toEntity(it) })
                assignmentDao.upsertInChunks(assignments.map { AssignmentMapper.toEntity(it) })
                submissionDao.upsertInChunks(submissions.map { SubmissionMapper.toEntity(it) })

                val restoredSnapshot = BackupSnapshot(
                    id = dto.id,
                    userId = dto.userId,
                    deviceId = dto.deviceId,
                    schemaVersion = dto.schemaVersion,
                    timestamp = System.currentTimeMillis(),
                    courses = courses,
                    assignments = assignments,
                    submissions = submissions,
                    checksum = dto.checksum
                )

                emit(Resource.Success(restoredSnapshot))
            }
            is Resource.Error -> emit(Resource.Error(remoteResult.message, remoteResult.cause))
            else -> emit(Resource.Error("Backup restore cancelled"))
        }
    }.flowOn(dispatchers.io)
}
