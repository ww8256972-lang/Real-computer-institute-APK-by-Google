package com.edusync.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.core.TokenManager
import com.edusync.app.data.repository.AuthRepository
import com.edusync.app.data.repository.BackupRestoreRepository
import com.edusync.app.data.repository.SyncRepository
import com.edusync.app.domain.model.BackupSnapshot
import com.edusync.app.domain.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val user: User? = null,
    val deviceId: String = "",
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val isBackingUp: Boolean = false,
    val isRestoring: Boolean = false,
    val lastSyncTime: Long = 0L,
    val lastBackup: BackupSnapshot? = null,
    val message: String? = null,
    val error: String? = null
)

class SettingsViewModel(
    private val authRepository: AuthRepository,
    private val syncRepository: SyncRepository,
    private val backupRestoreRepository: BackupRestoreRepository,
    private val networkMonitor: NetworkMonitor,
    private val tokenManager: TokenManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        SettingsUiState(
            user = authRepository.currentUser.value,
            deviceId = tokenManager.getDeviceId(),
            lastSyncTime = tokenManager.getLastSyncTime()
        )
    )
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        authRepository.currentUser.onEach { user ->
            _uiState.update { it.copy(user = user) }
        }.launchIn(viewModelScope)

        networkMonitor.isOnline.onEach { online ->
            _uiState.update { it.copy(isOnline = online) }
        }.launchIn(viewModelScope)
    }

    fun triggerSync() {
        syncRepository.synchronizeAll().onEach { res ->
            when (res) {
                is Resource.Loading -> _uiState.update { it.copy(isSyncing = true) }
                is Resource.Success -> {
                    val result = res.data
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            lastSyncTime = result.timestamp,
                            message = "Sync complete: ${result.uploadedCount} uploaded, ${result.downloadedCount} updated."
                        )
                    }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(isSyncing = false, error = res.message)
                }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun createBackup() {
        backupRestoreRepository.createAndUploadBackup().onEach { res ->
            when (res) {
                is Resource.Loading -> _uiState.update { it.copy(isBackingUp = true) }
                is Resource.Success -> {
                    _uiState.update {
                        it.copy(
                            isBackingUp = false,
                            lastBackup = res.data,
                            message = "Cloud backup created successfully (SHA-256: ${res.data.checksum.take(8)}...)"
                        )
                    }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(isBackingUp = false, error = res.message)
                }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun restoreBackup() {
        backupRestoreRepository.restoreLatestBackup().onEach { res ->
            when (res) {
                is Resource.Loading -> _uiState.update { it.copy(isRestoring = true) }
                is Resource.Success -> {
                    val snapshot = res.data
                    _uiState.update {
                        it.copy(
                            isRestoring = false,
                            lastBackup = snapshot,
                            message = "Restored ${snapshot.courses.size} courses, ${snapshot.assignments.size} assignments, and ${snapshot.submissions.size} submissions across devices."
                        )
                    }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(isRestoring = false, error = res.message)
                }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.signOut()
            onLoggedOut()
        }
    }

    fun dismissMessage() {
        _uiState.update { it.copy(message = null, error = null) }
    }
}
