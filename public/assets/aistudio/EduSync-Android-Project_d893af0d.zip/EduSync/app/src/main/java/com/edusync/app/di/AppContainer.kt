package com.edusync.app.di

import android.content.Context
import com.edusync.app.core.ConnectivityManagerNetworkMonitor
import com.edusync.app.core.DefaultDispatcherProvider
import com.edusync.app.core.DispatcherProvider
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.TokenManager
import com.edusync.app.data.local.AppDatabase
import com.edusync.app.data.remote.SupabaseConfig
import com.edusync.app.data.remote.api.SupabaseAuthService
import com.edusync.app.data.remote.api.SupabaseBackupService
import com.edusync.app.data.remote.api.SupabaseCourseService
import com.edusync.app.data.remote.realtime.SupabaseRealtimeManager
import com.edusync.app.data.repository.AssignmentRepository
import com.edusync.app.data.repository.AssignmentRepositoryImpl
import com.edusync.app.data.repository.AuthRepository
import com.edusync.app.data.repository.AuthRepositoryImpl
import com.edusync.app.data.repository.BackupRestoreRepository
import com.edusync.app.data.repository.BackupRestoreRepositoryImpl
import com.edusync.app.data.repository.CourseRepository
import com.edusync.app.data.repository.CourseRepositoryImpl
import com.edusync.app.data.repository.SyncRepository
import com.edusync.app.data.repository.SyncRepositoryImpl
import com.edusync.app.sync.SyncManager

interface AppContainer {
    val database: AppDatabase
    val tokenManager: TokenManager
    val networkMonitor: NetworkMonitor
    val dispatchers: DispatcherProvider
    val realtimeManager: SupabaseRealtimeManager
    val authRepository: AuthRepository
    val courseRepository: CourseRepository
    val assignmentRepository: AssignmentRepository
    val syncRepository: SyncRepository
    val backupRestoreRepository: BackupRestoreRepository
    val syncManager: SyncManager
}

class DefaultAppContainer(private val context: Context) : AppContainer {

    override val dispatchers: DispatcherProvider by lazy { DefaultDispatcherProvider() }

    override val networkMonitor: NetworkMonitor by lazy { ConnectivityManagerNetworkMonitor(context) }

    override val tokenManager: TokenManager by lazy { TokenManager(context) }

    override val database: AppDatabase by lazy { AppDatabase.getInstance(context) }

    private val supabaseClient by lazy { SupabaseConfig.client }

    private val authService by lazy { SupabaseAuthService(supabaseClient) }

    private val courseService by lazy { SupabaseCourseService(supabaseClient) }

    private val backupService by lazy { SupabaseBackupService(supabaseClient) }

    override val realtimeManager: SupabaseRealtimeManager by lazy { SupabaseRealtimeManager(supabaseClient) }

    override val authRepository: AuthRepository by lazy {
        AuthRepositoryImpl(
            authService = authService,
            userDao = database.userDao(),
            tokenManager = tokenManager,
            dispatchers = dispatchers
        )
    }

    override val courseRepository: CourseRepository by lazy {
        CourseRepositoryImpl(
            courseDao = database.courseDao(),
            syncQueueDao = database.syncQueueDao(),
            courseService = courseService,
            networkMonitor = networkMonitor,
            dispatchers = dispatchers
        )
    }

    override val assignmentRepository: AssignmentRepository by lazy {
        AssignmentRepositoryImpl(
            assignmentDao = database.assignmentDao(),
            submissionDao = database.submissionDao(),
            syncQueueDao = database.syncQueueDao(),
            courseService = courseService,
            networkMonitor = networkMonitor,
            dispatchers = dispatchers
        )
    }

    override val syncRepository: SyncRepository by lazy {
        SyncRepositoryImpl(
            syncQueueDao = database.syncQueueDao(),
            courseDao = database.courseDao(),
            assignmentDao = database.assignmentDao(),
            submissionDao = database.submissionDao(),
            courseService = courseService,
            networkMonitor = networkMonitor,
            tokenManager = tokenManager,
            dispatchers = dispatchers
        )
    }

    override val backupRestoreRepository: BackupRestoreRepository by lazy {
        BackupRestoreRepositoryImpl(
            courseDao = database.courseDao(),
            assignmentDao = database.assignmentDao(),
            submissionDao = database.submissionDao(),
            backupService = backupService,
            tokenManager = tokenManager,
            networkMonitor = networkMonitor,
            dispatchers = dispatchers
        )
    }

    override val syncManager: SyncManager by lazy { SyncManager(context) }
}
