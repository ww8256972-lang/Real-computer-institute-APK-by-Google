package com.edusync.app.data.remote.api

import com.edusync.app.core.Constants
import com.edusync.app.core.Resource
import com.edusync.app.data.remote.SupabaseConfig
import com.edusync.app.data.remote.dto.UserProfileDto
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class SupabaseAuthService(
    private val supabase: io.github.jan.supabase.SupabaseClient = SupabaseConfig.client
) {

    suspend fun signUp(
        email: String,
        password: String,
        displayName: String,
        role: String,
        deviceId: String
    ): Resource<UserProfileDto> {
        return try {
            val userMetadata = buildJsonObject {
                put("display_name", displayName)
                put("role", role)
                put("device_id", deviceId)
            }

            supabase.auth.signUpWith(Email) {
                this.email = email
                this.password = password
                this.data = userMetadata
            }

            val currentUser = supabase.auth.currentUserOrNull()
                ?: return Resource.Error("Sign up completed but no user session returned")

            val profile = UserProfileDto(
                id = currentUser.id,
                email = email,
                displayName = displayName,
                role = role,
                deviceId = deviceId
            )

            // Persist to profiles table via Postgrest
            supabase.postgrest[Constants.TABLE_PROFILES].upsert(profile)

            Resource.Success(profile)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Authentication sign-up failed", e)
        }
    }

    suspend fun signIn(email: String, password: String): Resource<UserProfileDto> {
        return try {
            supabase.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }

            val currentUser = supabase.auth.currentUserOrNull()
                ?: return Resource.Error("Sign in succeeded but user is null")

            // Fetch profile with assigned role
            val profile = supabase.postgrest[Constants.TABLE_PROFILES]
                .select {
                    filter {
                        eq("id", currentUser.id)
                    }
                }
                .decodeSingleOrNull<UserProfileDto>()

            if (profile != null) {
                Resource.Success(profile)
            } else {
                // If profile row doesn't exist yet, derive from user metadata
                val fallbackProfile = UserProfileDto(
                    id = currentUser.id,
                    email = currentUser.email ?: email,
                    displayName = email.substringBefore("@"),
                    role = "STUDENT"
                )
                supabase.postgrest[Constants.TABLE_PROFILES].upsert(fallbackProfile)
                Resource.Success(fallbackProfile)
            }
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Sign-in failed", e)
        }
    }

    suspend fun signOut(): Resource<Unit> {
        return try {
            supabase.auth.signOut()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Sign-out failed", e)
        }
    }

    suspend fun getProfile(userId: String): Resource<UserProfileDto> {
        return try {
            val profile = supabase.postgrest[Constants.TABLE_PROFILES]
                .select {
                    filter {
                        eq("id", userId)
                    }
                }
                .decodeSingleOrNull<UserProfileDto>()

            if (profile != null) {
                Resource.Success(profile)
            } else {
                Resource.Error("Profile not found for ID: $userId")
            }
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to fetch user profile", e)
        }
    }
}
