package com.edusync.app.data.repository

import com.edusync.app.core.DispatcherProvider
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.data.local.dao.CourseDao
import com.edusync.app.data.local.dao.SyncQueueDao
import com.edusync.app.data.local.entity.CourseEntity
import com.edusync.app.data.local.entity.SyncQueueEntity
import com.edusync.app.data.remote.api.SupabaseCourseService
import com.edusync.app.domain.mapper.CourseMapper
import com.edusync.app.domain.model.Course
import com.edusync.app.domain.model.SyncEntityType
import com.edusync.app.domain.model.SyncOperationType
import com.edusync.app.domain.model.SyncStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

interface CourseRepository {
    fun observeCourses(searchQuery: String? = null): Flow<List<Course>>
    fun observeCourseById(id: String): Flow<Course?>
    suspend fun getCourseById(id: String): Course?
    suspend fun createCourse(course: Course): Resource<Course>
    suspend fun updateCourse(course: Course): Resource<Course>
    suspend fun deleteCourse(courseId: String): Resource<Unit>
    suspend fun refreshCourses(): Resource<Int>
    suspend fun bulkImportCourses(courses: List<Course>): Resource<Int>
    suspend fun getCourseCount(): Int
}

class CourseRepositoryImpl(
    private val courseDao: CourseDao,
    private val syncQueueDao: SyncQueueDao,
    private val courseService: SupabaseCourseService,
    private val networkMonitor: NetworkMonitor,
    private val dispatchers: DispatcherProvider
) : CourseRepository {

    override fun observeCourses(searchQuery: String?): Flow<List<Course>> {
        val flow = if (searchQuery.isNullOrBlank()) {
            courseDao.observeActiveCourses()
        } else {
            courseDao.searchCourses(searchQuery.trim())
        }
        return flow.map { list -> list.map { CourseMapper.toDomain(it) } }
            .flowOn(dispatchers.io)
    }

    override fun observeCourseById(id: String): Flow<Course?> {
        return courseDao.observeCourseById(id)
            .map { it?.let { entity -> CourseMapper.toDomain(entity) } }
            .flowOn(dispatchers.io)
    }

    override suspend fun getCourseById(id: String): Course? = withContext(dispatchers.io) {
        courseDao.getCourseById(id)?.let { CourseMapper.toDomain(it) }
    }

    override suspend fun createCourse(course: Course): Resource<Course> = withContext(dispatchers.io) {
        val now = System.currentTimeMillis()
        val preparedCourse = course.copy(
            id = if (course.id.isBlank()) UUID.randomUUID().toString() else course.id,
            createdAt = if (course.createdAt == 0L) now else course.createdAt,
            updatedAt = now,
            syncStatus = if (networkMonitor.isCurrentlyConnected()) SyncStatus.SYNCED else SyncStatus.PENDING_INSERT
        )

        val entity = CourseMapper.toEntity(preparedCourse)
        courseDao.insertOrUpdate(entity)

        // Queue for sync or push immediately
        if (networkMonitor.isCurrentlyConnected()) {
            val dto = CourseMapper.toDto(preparedCourse)
            when (val remoteResult = courseService.upsertCourse(dto)) {
                is Resource.Success -> {
                    courseDao.updateSyncStatus(preparedCourse.id, SyncStatus.SYNCED)
                    Resource.Success(preparedCourse.copy(syncStatus = SyncStatus.SYNCED))
                }
                is Resource.Error -> {
                    // Fallback to queue on remote error
                    enqueueCourseOperation(preparedCourse, SyncOperationType.CREATE)
                    courseDao.updateSyncStatus(preparedCourse.id, SyncStatus.PENDING_INSERT)
                    Resource.Success(preparedCourse.copy(syncStatus = SyncStatus.PENDING_INSERT))
                }
                else -> Resource.Success(preparedCourse)
            }
        } else {
            enqueueCourseOperation(preparedCourse, SyncOperationType.CREATE)
            Resource.Success(preparedCourse.copy(syncStatus = SyncStatus.PENDING_INSERT))
        }
    }

    override suspend fun updateCourse(course: Course): Resource<Course> = withContext(dispatchers.io) {
        val updatedCourse = course.copy(
            updatedAt = System.currentTimeMillis(),
            syncStatus = if (networkMonitor.isCurrentlyConnected()) SyncStatus.SYNCED else SyncStatus.PENDING_UPDATE
        )

        val entity = CourseMapper.toEntity(updatedCourse)
        courseDao.insertOrUpdate(entity)

        if (networkMonitor.isCurrentlyConnected()) {
            val dto = CourseMapper.toDto(updatedCourse)
            when (val remoteResult = courseService.upsertCourse(dto)) {
                is Resource.Success -> {
                    courseDao.updateSyncStatus(updatedCourse.id, SyncStatus.SYNCED)
                    Resource.Success(updatedCourse.copy(syncStatus = SyncStatus.SYNCED))
                }
                is Resource.Error -> {
                    enqueueCourseOperation(updatedCourse, SyncOperationType.UPDATE)
                    courseDao.updateSyncStatus(updatedCourse.id, SyncStatus.PENDING_UPDATE)
                    Resource.Success(updatedCourse.copy(syncStatus = SyncStatus.PENDING_UPDATE))
                }
                else -> Resource.Success(updatedCourse)
            }
        } else {
            enqueueCourseOperation(updatedCourse, SyncOperationType.UPDATE)
            Resource.Success(updatedCourse.copy(syncStatus = SyncStatus.PENDING_UPDATE))
        }
    }

    override suspend fun deleteCourse(courseId: String): Resource<Unit> = withContext(dispatchers.io) {
        val existing = courseDao.getCourseById(courseId)
        if (existing != null) {
            // Soft delete locally first or remove
            val archived = existing.copy(isArchived = true, syncStatus = SyncStatus.PENDING_DELETE, updatedAt = System.currentTimeMillis())
            courseDao.insertOrUpdate(archived)

            if (networkMonitor.isCurrentlyConnected()) {
                when (val remoteResult = courseService.deleteCourse(courseId)) {
                    is Resource.Success -> {
                        courseDao.deleteById(courseId)
                        Resource.Success(Unit)
                    }
                    is Resource.Error -> {
                        enqueueCourseOperation(CourseMapper.toDomain(archived), SyncOperationType.DELETE)
                        Resource.Success(Unit)
                    }
                    else -> Resource.Success(Unit)
                }
            } else {
                enqueueCourseOperation(CourseMapper.toDomain(archived), SyncOperationType.DELETE)
                Resource.Success(Unit)
            }
        } else {
            Resource.Error("Course not found for deletion")
        }
    }

    override suspend fun refreshCourses(): Resource<Int> = withContext(dispatchers.io) {
        if (!networkMonitor.isCurrentlyConnected()) {
            return@withContext Resource.Error("Network is unavailable. Using cached offline data.")
        }

        when (val result = courseService.fetchAllCourses()) {
            is Resource.Success -> {
                val remoteDtos = result.data
                val remoteEntities = remoteDtos.map { CourseMapper.toEntity(it, SyncStatus.SYNCED) }

                // Merge with Last-Write-Wins (LWW) conflict resolution
                val localEntities = courseDao.getAllCourses().associateBy { it.id }
                val mergedList = mutableListOf<CourseEntity>()

                for (remote in remoteEntities) {
                    val local = localEntities[remote.id]
                    if (local == null) {
                        mergedList.add(remote)
                    } else {
                        // If local has pending changes that haven't synced yet, preserve local unless remote is newer
                        if (local.syncStatus == SyncStatus.PENDING_UPDATE || local.syncStatus == SyncStatus.PENDING_INSERT) {
                            if (local.updatedAt >= remote.updatedAt) {
                                mergedList.add(local)
                            } else {
                                mergedList.add(remote)
                            }
                        } else {
                            mergedList.add(remote)
                        }
                    }
                }

                // Batch upsert in bounded chunks to handle thousands of records safely
                courseDao.upsertInChunks(mergedList)
                Resource.Success(mergedList.size)
            }
            is Resource.Error -> Resource.Error(result.message, result.cause)
            else -> Resource.Error("Unknown sync state")
        }
    }

    override suspend fun bulkImportCourses(courses: List<Course>): Resource<Int> = withContext(dispatchers.io) {
        val entities = courses.map { CourseMapper.toEntity(it) }
        courseDao.upsertInChunks(entities)

        if (networkMonitor.isCurrentlyConnected()) {
            val dtos = courses.map { CourseMapper.toDto(it) }
            courseService.upsertCoursesBatch(dtos)
        }
        Resource.Success(courses.size)
    }

    override suspend fun getCourseCount(): Int = withContext(dispatchers.io) {
        courseDao.getCourseCount()
    }

    private suspend fun enqueueCourseOperation(course: Course, operation: SyncOperationType) {
        val jsonPayload = Json.encodeToString(course)
        val queueItem = SyncQueueEntity(
            id = UUID.randomUUID().toString(),
            entityType = SyncEntityType.COURSE,
            entityId = course.id,
            operation = operation,
            payloadJson = jsonPayload,
            status = SyncStatus.PENDING_INSERT
        )
        syncQueueDao.enqueue(queueItem)
    }
}
