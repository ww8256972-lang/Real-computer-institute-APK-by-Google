package com.edusync.app.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class BackupSnapshotDto(
    @SerialName("id")
    val id: String,
    @SerialName("user_id")
    val userId: String,
    @SerialName("device_id")
    val deviceId: String,
    @SerialName("schema_version")
    val schemaVersion: Int,
    @SerialName("record_count")
    val recordCount: Int,
    @SerialName("checksum")
    val checksum: String,
    @SerialName("payload")
    val payload: String,
    @SerialName("created_at")
    val createdAt: String? = null
)
