package com.edusync.app.domain.mapper

import com.edusync.app.data.local.entity.AssignmentEntity
import com.edusync.app.data.remote.dto.AssignmentDto
import com.edusync.app.domain.model.Assignment
import com.edusync.app.domain.model.SyncStatus
import java.time.Instant

object AssignmentMapper {

    fun toDomain(entity: AssignmentEntity): Assignment {
        return Assignment(
            id = entity.id,
            courseId = entity.courseId,
            title = entity.title,
            description = entity.description,
            dueDate = entity.dueDate,
            maxPoints = entity.maxPoints,
            createdAt = entity.createdAt,
            updatedAt = entity.updatedAt,
            syncStatus = entity.syncStatus
        )
    }

    fun toEntity(domain: Assignment, syncStatus: SyncStatus? = null): AssignmentEntity {
        return AssignmentEntity(
            id = domain.id,
            courseId = domain.courseId,
            title = domain.title,
            description = domain.description,
            dueDate = domain.dueDate,
            maxPoints = domain.maxPoints,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt,
            syncStatus = syncStatus ?: domain.syncStatus
        )
    }

    fun toEntity(dto: AssignmentDto, syncStatus: SyncStatus = SyncStatus.SYNCED): AssignmentEntity {
        val now = System.currentTimeMillis()
        val createdEpoch = UserMapper.parseIsoToEpoch(dto.createdAt, now)
        val updatedEpoch = UserMapper.parseIsoToEpoch(dto.updatedAt, now)
        val dueEpoch = UserMapper.parseIsoToEpoch(dto.dueDate, now + 86400000L * 7)

        return AssignmentEntity(
            id = dto.id,
            courseId = dto.courseId,
            title = dto.title,
            description = dto.description,
            dueDate = dueEpoch,
            maxPoints = dto.maxPoints,
            createdAt = createdEpoch,
            updatedAt = updatedEpoch,
            syncStatus = syncStatus
        )
    }

    fun toDto(domain: Assignment): AssignmentDto {
        return AssignmentDto(
            id = domain.id,
            courseId = domain.courseId,
            title = domain.title,
            description = domain.description,
            dueDate = Instant.ofEpochMilli(domain.dueDate).toString(),
            maxPoints = domain.maxPoints,
            createdAt = Instant.ofEpochMilli(domain.createdAt).toString(),
            updatedAt = Instant.ofEpochMilli(domain.updatedAt).toString()
        )
    }
}
