package com.edusync.app.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.util.UUID

class TokenManager(context: Context) {

    private val sharedPreferences: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            Constants.PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback for devices/emulators where Android KeyStore might encounter initialization issues
        context.getSharedPreferences(Constants.PREFS_FILE, Context.MODE_PRIVATE)
    }

    fun saveAuthTokens(accessToken: String, refreshToken: String?, userId: String, role: String) {
        sharedPreferences.edit()
            .putString(Constants.KEY_AUTH_TOKEN, accessToken)
            .putString(Constants.KEY_REFRESH_TOKEN, refreshToken)
            .putString(Constants.KEY_USER_ID, userId)
            .putString(Constants.KEY_USER_ROLE, role)
            .apply()
    }

    fun getAccessToken(): String? = sharedPreferences.getString(Constants.KEY_AUTH_TOKEN, null)
    fun getRefreshToken(): String? = sharedPreferences.getString(Constants.KEY_REFRESH_TOKEN, null)
    fun getUserId(): String? = sharedPreferences.getString(Constants.KEY_USER_ID, null)
    fun getUserRole(): String? = sharedPreferences.getString(Constants.KEY_USER_ROLE, null)

    fun getDeviceId(): String {
        var deviceId = sharedPreferences.getString(Constants.KEY_DEVICE_ID, null)
        if (deviceId.isNullOrEmpty()) {
            deviceId = UUID.randomUUID().toString()
            sharedPreferences.edit().putString(Constants.KEY_DEVICE_ID, deviceId).apply()
        }
        return deviceId
    }

    fun setLastSyncTime(timestamp: Long) {
        sharedPreferences.edit().putLong(Constants.KEY_LAST_SYNC_TIMESTAMP, timestamp).apply()
    }

    fun getLastSyncTime(): Long = sharedPreferences.getLong(Constants.KEY_LAST_SYNC_TIMESTAMP, 0L)

    fun clearSession() {
        val deviceId = getDeviceId()
        sharedPreferences.edit().clear().apply()
        // Preserve device identifier across logouts
        sharedPreferences.edit().putString(Constants.KEY_DEVICE_ID, deviceId).apply()
    }

    companion object {
        fun computeSha256(content: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(content.toByteArray(Charsets.UTF_8))
            return hashBytes.joinToString("") { "%02x".format(it) }
        }
    }
}
