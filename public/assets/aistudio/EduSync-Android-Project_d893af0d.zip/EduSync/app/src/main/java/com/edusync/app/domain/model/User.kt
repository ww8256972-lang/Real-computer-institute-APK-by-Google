package com.edusync.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class User(
    val id: String,
    val email: String,
    val displayName: String,
    val role: Role,
    val deviceId: String,
    val createdAt: Long,
    val updatedAt: Long
)
