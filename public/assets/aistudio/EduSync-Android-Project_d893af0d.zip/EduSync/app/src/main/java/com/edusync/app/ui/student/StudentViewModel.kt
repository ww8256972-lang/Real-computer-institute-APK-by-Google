package com.edusync.app.ui.student

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edusync.app.core.NetworkMonitor
import com.edusync.app.core.Resource
import com.edusync.app.core.TokenManager
import com.edusync.app.data.repository.AssignmentRepository
import com.edusync.app.data.repository.CourseRepository
import com.edusync.app.data.repository.SyncRepository
import com.edusync.app.domain.model.Assignment
import com.edusync.app.domain.model.Course
import com.edusync.app.domain.model.Submission
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class StudentUiState(
    val courses: List<Course> = emptyList(),
    val assignments: List<Assignment> = emptyList(),
    val submissions: Map<String, Submission> = emptyMap(),
    val selectedCourse: Course? = null,
    val isLoading: Boolean = false,
    val isSyncing: Boolean = false,
    val pendingSyncCount: Int = 0,
    val isOffline: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

class StudentViewModel(
    private val courseRepository: CourseRepository,
    private val assignmentRepository: AssignmentRepository,
    private val syncRepository: SyncRepository,
    private val networkMonitor: NetworkMonitor,
    private val tokenManager: TokenManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(StudentUiState())
    val uiState: StateFlow<StudentUiState> = _uiState.asStateFlow()

    private val currentUserId: String get() = tokenManager.getUserId() ?: ""

    init {
        // Observe courses
        courseRepository.observeCourses().onEach { courses ->
            _uiState.update { it.copy(courses = courses) }
        }.launchIn(viewModelScope)

        // Observe network state
        networkMonitor.isOnline.onEach { online ->
            _uiState.update { it.copy(isOffline = !online) }
        }.launchIn(viewModelScope)

        // Observe pending sync count
        syncRepository.observePendingSyncCount().onEach { count ->
            _uiState.update { it.copy(pendingSyncCount = count) }
        }.launchIn(viewModelScope)

        // Observe student's submissions
        if (currentUserId.isNotEmpty()) {
            assignmentRepository.observeStudentSubmissions(currentUserId).onEach { subs ->
                _uiState.update { it.copy(submissions = subs.associateBy { sub -> sub.assignmentId }) }
            }.launchIn(viewModelScope)
        }
    }

    fun loadCourseDetails(courseId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val course = courseRepository.getCourseById(courseId)
            _uiState.update { it.copy(selectedCourse = course) }

            assignmentRepository.observeAssignments(courseId).onEach { assignments ->
                _uiState.update { it.copy(assignments = assignments, isLoading = false) }
            }.launchIn(viewModelScope)
        }
    }

    fun submitAssignment(assignmentId: String, content: String) {
        if (content.isBlank()) {
            _uiState.update { it.copy(error = "Submission content cannot be empty") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = assignmentRepository.submitWork(assignmentId, currentUserId, content.trim())
            _uiState.update {
                it.copy(
                    isLoading = false,
                    message = if (result is Resource.Success) "Assignment submitted successfully (queued if offline)" else null,
                    error = if (result is Resource.Error) result.message else null
                )
            }
        }
    }

    fun triggerSync() {
        syncRepository.synchronizeAll().onEach { resource ->
            when (resource) {
                is Resource.Loading -> _uiState.update { it.copy(isSyncing = true) }
                is Resource.Success -> {
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            message = "Synced successfully with cloud"
                        )
                    }
                }
                is Resource.Error -> _uiState.update {
                    it.copy(isSyncing = false, error = resource.message)
                }
                Resource.Idle -> Unit
            }
        }.launchIn(viewModelScope)
    }

    fun dismissMessage() {
        _uiState.update { it.copy(message = null, error = null) }
    }
}
