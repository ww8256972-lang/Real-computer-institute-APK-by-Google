package com.edusync.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.edusync.app.ui.admin.AdminViewModel
import com.edusync.app.ui.auth.AuthViewModel
import com.edusync.app.ui.navigation.EduSyncNavGraph
import com.edusync.app.ui.settings.SettingsViewModel
import com.edusync.app.ui.student.StudentViewModel
import com.edusync.app.ui.theme.EduSyncTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as EduSyncApplication
        val container = app.container

        // Factory / instantiation of ViewModels using AppContainer
        val authViewModel = AuthViewModel(container.authRepository)
        val adminViewModel = AdminViewModel(
            courseRepository = container.courseRepository,
            assignmentRepository = container.assignmentRepository,
            syncRepository = container.syncRepository,
            networkMonitor = container.networkMonitor
        )
        val studentViewModel = StudentViewModel(
            courseRepository = container.courseRepository,
            assignmentRepository = container.assignmentRepository,
            syncRepository = container.syncRepository,
            networkMonitor = container.networkMonitor,
            tokenManager = container.tokenManager
        )
        val settingsViewModel = SettingsViewModel(
            authRepository = container.authRepository,
            syncRepository = container.syncRepository,
            backupRestoreRepository = container.backupRestoreRepository,
            networkMonitor = container.networkMonitor,
            tokenManager = container.tokenManager
        )

        setContent {
            EduSyncTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    EduSyncNavGraph(
                        navController = navController,
                        authViewModel = authViewModel,
                        adminViewModel = adminViewModel,
                        studentViewModel = studentViewModel,
                        settingsViewModel = settingsViewModel
                    )
                }
            }
        }
    }
}
