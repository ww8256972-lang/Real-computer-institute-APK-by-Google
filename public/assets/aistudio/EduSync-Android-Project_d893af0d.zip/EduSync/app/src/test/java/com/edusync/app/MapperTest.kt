package com.edusync.app

import com.edusync.app.data.local.entity.CourseEntity
import com.edusync.app.data.remote.dto.CourseDto
import com.edusync.app.domain.mapper.CourseMapper
import com.edusync.app.domain.mapper.UserMapper
import com.edusync.app.domain.model.Course
import com.edusync.app.domain.model.SyncStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import java.time.Instant

class MapperTest {

    @Test
    fun testCourseDomainToEntityAndBack() {
        val domain = Course(
            id = "course_123",
            title = "Distributed Systems",
            description = "Consensus and Replication",
            instructorId = "prof_456",
            category = "Computer Science",
            enrolledCount = 42,
            isArchived = false,
            createdAt = 1700000000000L,
            updatedAt = 1700005000000L,
            syncStatus = SyncStatus.SYNCED
        )

        val entity = CourseMapper.toEntity(domain)
        assertEquals(domain.id, entity.id)
        assertEquals(domain.title, entity.title)
        assertEquals(domain.category, entity.category)
        assertEquals(domain.enrolledCount, entity.enrolledCount)
        assertEquals(domain.syncStatus, entity.syncStatus)

        val convertedBack = CourseMapper.toDomain(entity)
        assertEquals(domain, convertedBack)
    }

    @Test
    fun testCourseDtoMapping() {
        val nowIso = Instant.now().toString()
        val dto = CourseDto(
            id = "c_999",
            title = "Cloud Native Computing",
            description = "Kubernetes & Microservices",
            instructorId = null,
            category = "Cloud",
            enrolledCount = 10,
            isArchived = false,
            createdAt = nowIso,
            updatedAt = nowIso
        )

        val entity = CourseMapper.toEntity(dto, SyncStatus.SYNCED)
        assertEquals("c_999", entity.id)
        assertEquals("Cloud Native Computing", entity.title)
        assertFalse(entity.isArchived)
        assertEquals(SyncStatus.SYNCED, entity.syncStatus)
    }

    @Test
    fun testIsoDateParsingFallback() {
        val fallback = 123456789L
        val parsed = UserMapper.parseIsoToEpoch("invalid_iso_string", fallback)
        assertEquals(fallback, parsed)
    }
}
