package com.edusync.app

import com.edusync.app.core.Constants
import com.edusync.app.core.SecurityUtils
import com.edusync.app.core.TokenManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncRepositoryTest {

    @Test
    fun testChecksumCalculation() {
        val payload1 = "{\"course\":\"Data Structures\"}"
        val payload2 = "{\"course\":\"Data Structures\"}"
        val payload3 = "{\"course\":\"Algorithms\"}"

        val checksum1 = TokenManager.computeSha256(payload1)
        val checksum2 = TokenManager.computeSha256(payload2)
        val checksum3 = TokenManager.computeSha256(payload3)

        assertEquals(checksum1, checksum2)
        assertNotEquals(checksum1, checksum3)
        assertEquals(64, checksum1.length) // SHA-256 hex string length
    }

    @Test
    fun testExponentialBackoffFormula() {
        val baseDelay = Constants.INITIAL_BACKOFF_MILLIS
        val retry0 = (baseDelay * (1 shl 0)).coerceAtMost(30000L)
        val retry1 = (baseDelay * (1 shl 1)).coerceAtMost(30000L)
        val retry2 = (baseDelay * (1 shl 2)).coerceAtMost(30000L)
        val retry3 = (baseDelay * (1 shl 3)).coerceAtMost(30000L)

        assertEquals(3000L, retry0)
        assertEquals(6000L, retry1)
        assertEquals(12000L, retry2)
        assertEquals(24000L, retry3)
    }

    @Test
    fun testMaxRetryBound() {
        assertTrue(Constants.MAX_RETRY_ATTEMPTS >= 3)
    }
}
