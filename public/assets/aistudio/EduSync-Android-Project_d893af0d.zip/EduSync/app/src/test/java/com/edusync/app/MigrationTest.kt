package com.edusync.app

import com.edusync.app.data.local.AppDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MigrationTest {

    @Test
    fun verifyMigrationVersions() {
        val migration = AppDatabase.MIGRATION_1_2
        assertEquals(1, migration.startVersion)
        assertEquals(2, migration.endVersion)
    }

    @Test
    fun verifyDatabaseVersion() {
        assertEquals(2, com.edusync.app.core.Constants.DATABASE_VERSION)
    }
}
